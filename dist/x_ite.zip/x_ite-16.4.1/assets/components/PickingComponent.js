/* X_ITE v16.4.1 */
const __X_ITE_X3D__ = window [Symbol .for ("X_ITE.X3D")];
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	const __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = (module) => {
/******/ 		const getter = module && module.__esModule ?
/******/ 			() => (module['default']) :
/******/ 			() => (module);
/******/ 		__webpack_require__.d(getter, { a: getter });
/******/ 		return getter;
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	// define getter/value functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
/******/ 	
/************************************************************************/

// UNUSED EXPORTS: default

;// external "__X_ITE_X3D__ .Components"
const external_X_ITE_X3D_Components_namespaceObject = __X_ITE_X3D__ .Components;
var external_X_ITE_X3D_Components_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Components_namespaceObject);
;// external "__X_ITE_X3D__ .Fields"
const external_X_ITE_X3D_Fields_namespaceObject = __X_ITE_X3D__ .Fields;
var external_X_ITE_X3D_Fields_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Fields_namespaceObject);
;// external "__X_ITE_X3D__ .X3DFieldDefinition"
const external_X_ITE_X3D_X3DFieldDefinition_namespaceObject = __X_ITE_X3D__ .X3DFieldDefinition;
var external_X_ITE_X3D_X3DFieldDefinition_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DFieldDefinition_namespaceObject);
;// external "__X_ITE_X3D__ .FieldDefinitionArray"
const external_X_ITE_X3D_FieldDefinitionArray_namespaceObject = __X_ITE_X3D__ .FieldDefinitionArray;
var external_X_ITE_X3D_FieldDefinitionArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_FieldDefinitionArray_namespaceObject);
;// external "__X_ITE_X3D__ .X3DNode"
const external_X_ITE_X3D_X3DNode_namespaceObject = __X_ITE_X3D__ .X3DNode;
var external_X_ITE_X3D_X3DNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DNode_namespaceObject);
;// external "__X_ITE_X3D__ .X3DSensorNode"
const external_X_ITE_X3D_X3DSensorNode_namespaceObject = __X_ITE_X3D__ .X3DSensorNode;
var external_X_ITE_X3D_X3DSensorNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DSensorNode_namespaceObject);
;// external "__X_ITE_X3D__ .X3DConstants"
const external_X_ITE_X3D_X3DConstants_namespaceObject = __X_ITE_X3D__ .X3DConstants;
var external_X_ITE_X3D_X3DConstants_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DConstants_namespaceObject);
;// external "__X_ITE_X3D__ .Namespace"
const external_X_ITE_X3D_Namespace_namespaceObject = __X_ITE_X3D__ .Namespace;
var external_X_ITE_X3D_Namespace_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Namespace_namespaceObject);
;// ./src/x_ite/Browser/Picking/MatchCriterion.js
let i = 0;

const MatchCriterion =
{
   MATCH_ANY:      i ++,
   MATCH_EVERY:    i ++,
   MATCH_ONLY_ONE: i ++,
};

const __default__ = MatchCriterion;
;

/* harmony default export */ const Picking_MatchCriterion = (external_X_ITE_X3D_Namespace_default().add ("MatchCriterion", __default__));
;// ./src/x_ite/Browser/Picking/IntersectionType.js
let IntersectionType_i = 0;

const IntersectionType =
{
   BOUNDS:   IntersectionType_i ++,
   GEOMETRY: IntersectionType_i ++,
};

const IntersectionType_default_ = IntersectionType;
;

/* harmony default export */ const Picking_IntersectionType = (external_X_ITE_X3D_Namespace_default().add ("IntersectionType", IntersectionType_default_));
;// ./src/x_ite/Browser/Picking/SortOrder.js
let SortOrder_i = 0;

const SortOrder =
{
   ANY:        SortOrder_i ++,
   CLOSEST:    SortOrder_i ++,
   ALL:        SortOrder_i ++,
   ALL_SORTED: SortOrder_i ++,
};

const SortOrder_default_ = SortOrder;
;

/* harmony default export */ const Picking_SortOrder = (external_X_ITE_X3D_Namespace_default().add ("SortOrder", SortOrder_default_));
;// external "__X_ITE_X3D__ .Matrix4"
const external_X_ITE_X3D_Matrix4_namespaceObject = __X_ITE_X3D__ .Matrix4;
var external_X_ITE_X3D_Matrix4_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Matrix4_namespaceObject);
;// external "__X_ITE_X3D__ .QuickSort"
const external_X_ITE_X3D_QuickSort_namespaceObject = __X_ITE_X3D__ .QuickSort;
var external_X_ITE_X3D_QuickSort_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_QuickSort_namespaceObject);
;// external "__X_ITE_X3D__ .ObjectCache"
const external_X_ITE_X3D_ObjectCache_namespaceObject = __X_ITE_X3D__ .ObjectCache;
var external_X_ITE_X3D_ObjectCache_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_ObjectCache_namespaceObject);
;// ./src/x_ite/Components/Picking/X3DPickSensorNode.js











const ModelMatrixCache = external_X_ITE_X3D_ObjectCache_default() ((external_X_ITE_X3D_Matrix4_default()));

function compareDistance (lhs, rhs) { return lhs .distance < rhs .distance; }

function X3DPickSensorNode (executionContext)
{
   external_X_ITE_X3D_X3DSensorNode_default().call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).X3DPickSensorNode);

   // Private properties

   this .objectType          = new Set ();
   this .intersectionType    = Picking_IntersectionType .BOUNDS;
   this .sortOrder           = Picking_SortOrder .CLOSEST;
   this .pickTargetNodes     = new Set ();
   this .modelMatrices       = [ ];
   this .targets             = [ ];
   this .targets .size       = 0;
   this .pickedTargets       = [ ];
   this .pickedTargetsSorter = new (external_X_ITE_X3D_QuickSort_default()) (this .pickedTargets, compareDistance);
   this .pickedGeometries    = new (external_X_ITE_X3D_Fields_default()).MFNode (); // Must be unique for each X3DPickSensorNode.
}

Object .assign (Object .setPrototypeOf (X3DPickSensorNode .prototype, (external_X_ITE_X3D_X3DSensorNode_default()).prototype),
{
   initialize ()
   {
      this .getLive () .addInterest ("set_live__", this);

      this ._enabled          .addInterest ("set_live__",             this);
      this ._objectType       .addInterest ("set_objectType__",       this);
      this ._matchCriterion   .addInterest ("set_matchCriterion__",   this);
      this ._intersectionType .addInterest ("set_intersectionType__", this);
      this ._sortOrder        .addInterest ("set_sortOrder__",        this);
      this ._pickTarget       .addInterest ("set_pickTarget__",       this);

      this .set_objectType__ ();
      this .set_matchCriterion__ ();
      this .set_intersectionType__ ();
      this .set_sortOrder__ ();
      this .set_pickTarget__ ();
   },
   getObjectType ()
   {
      return this .objectType;
   },
   getMatchCriterion ()
   {
      return this .matchCriterion;
   },
   getIntersectionType ()
   {
      return this .intersectionType;
   },
   getSortOrder ()
   {
      return this .sortOrder;
   },
   getModelMatrices ()
   {
      return this .modelMatrices;
   },
   getTargets ()
   {
      return this .targets;
   },
   getPickShape: (() =>
   {
      const pickShapes = new WeakMap ();

      return function (geometryNode)
      {
         const pickShape = pickShapes .get (geometryNode);

         if (pickShape !== undefined)
            return pickShape;

         const
            browser             = this .getBrowser (),
            privateScene        = browser .getPrivateScene (),
            shapeNode           = privateScene .createNode ("Shape",           false),
            collidableShapeNode = privateScene .createNode ("CollidableShape", false);

         shapeNode .setPrivate (true);
         collidableShapeNode .setPrivate (true);
         collidableShapeNode .setConvex (true);

         shapeNode ._geometry        = geometryNode;
         collidableShapeNode ._shape = shapeNode;

         shapeNode           .setup ();
         collidableShapeNode .setup ();

         pickShapes .set (geometryNode, collidableShapeNode);

         return collidableShapeNode;
      };
   })(),
   getPickedGeometries ()
   {
      const
         targets          = this .targets,
         numTargets       = targets .size,
         pickedTargets    = this .pickedTargets,
         pickedGeometries = this .pickedGeometries;

      // Filter intersecting targets.

      pickedTargets .length = 0;

      for (let i = 0; i < numTargets; ++ i)
      {
         const target = targets [i];

         if (target .intersected)
            pickedTargets .push (target);
      }

      // No pickedTargets, return.

      if (pickedTargets .length === 0)
      {
         pickedGeometries .length = 0;

         return pickedGeometries;
      }

      // Return sorted pickedTargets.

      switch (this .sortOrder)
      {
         case Picking_SortOrder .CLOSEST:
         {
            this .pickedTargetsSorter .sort (0, pickedTargets .length);

            // falls through
         }
         case Picking_SortOrder .ANY:
         {
            pickedGeometries [0] = null;

            const numPickedTargets = pickedTargets .length;

            for (let i = 0; i < numPickedTargets; ++ i)
            {
               if ((pickedGeometries [0] = this .getPickedGeometry (pickedTargets [i])))
                  break;
            }

            pickedGeometries .length = 1;
            break;
         }
         case Picking_SortOrder .ALL_SORTED:
         {
            this .pickedTargetsSorter .sort (0, pickedTargets .length);

            // falls through
         }
         case Picking_SortOrder .ALL:
         {
            const numPickedTargets = pickedTargets .length;

            for (let i = 0; i < numPickedTargets; ++ i)
               pickedGeometries [i] = this .getPickedGeometry (pickedTargets [i]);

            pickedGeometries .length = numPickedTargets;
            break;
         }
      }

      pickedGeometries .assign (pickedGeometries .filter (node => node));

      return pickedGeometries;
   },
   getPickedGeometry (target)
   {
      const geometryNode = target .geometryNode;

      if (geometryNode .isPrivate ())
         return null;

      if (geometryNode .getExecutionContext () .isPrivate ())
         return null;

      return geometryNode;
   },
   getPickedTargets ()
   {
      return this .pickedTargets;
   },
   set_live__ ()
   {
      if (this .getLive () .getValue () && this ._enabled .getValue () && !this .objectType .has ("NONE"))
      {
         this .getBrowser () .addPickSensor (this);
         this .setPickableObject (true);
      }
      else
      {
         this .getBrowser () .removePickSensor (this);
         this .setPickableObject (false);
      }
   },
   set_objectType__ ()
   {
      this .objectType .clear ();

      for (const objectType of this ._objectType)
         this .objectType .add (objectType);

      this .set_live__ ();
   },
   set_matchCriterion__: (() =>
   {
      const matchCriterions = new Map (Object .entries (Picking_MatchCriterion));

      return function ()
      {
         this .matchCriterion = matchCriterions .get (this ._matchCriterion .getValue ())
            ?? Picking_MatchCriterion .MATCH_ANY;
      };
   })(),
   set_intersectionType__: (() =>
   {
      const intersectionTypes = new Map (Object .entries (Picking_IntersectionType));

      return function ()
      {
         this .intersectionType = intersectionTypes .get (this ._intersectionType .getValue ())
            ?? Picking_IntersectionType .BOUNDS;
      };
   })(),
   set_sortOrder__: (() =>
   {
      const sortOrders = new Map (Object .entries (Picking_SortOrder));

      return function ()
      {
         this .sortOrder = sortOrders .get (this ._sortOrder .getValue ())
            ?? Picking_SortOrder .CLOSEST;
      };
   })(),
   set_pickTarget__ ()
   {
      this .pickTargetNodes .clear ();

      for (const node of this ._pickTarget)
      {
         try
         {
            const
               innerNode = node .getValue () .getInnerNode (),
               type      = innerNode .getType ();

            for (let t = type .length - 1; t >= 0; -- t)
            {
               switch (type [t])
               {
                  case (external_X_ITE_X3D_X3DConstants_default()).Inline:
                  case (external_X_ITE_X3D_X3DConstants_default()).Shape:
                  case (external_X_ITE_X3D_X3DConstants_default()).X3DGroupingNode:
                  {
                     this .pickTargetNodes .add (innerNode);
                     break;
                  }
                  default:
                     continue;
               }

               break;
            }
         }
         catch
         { }
      }
   },
   traverse (type, renderObject)
   {
      this .modelMatrices .push (ModelMatrixCache .pop () .assign (renderObject .getModelViewMatrix () .get ()));
   },
   collect (geometryNode, modelMatrix, pickingHierarchy)
   {
      const
         pickTargetNodes = this .pickTargetNodes,
         haveTarget      = pickingHierarchy .some (node => pickTargetNodes .has (node));

      if (!haveTarget)
         return;

      const targets = this .targets;

      let target;

      if (targets .size < targets .length)
      {
         target = targets [targets .size];
      }
      else
      {
         targets .push (target = {
            modelMatrix: new (external_X_ITE_X3D_Matrix4_default()) (),
            pickedPoint: [ ],
            intersections: [ ],
         });
      }

      ++ targets .size;

      target .intersected           = false;
      target .geometryNode          = geometryNode;
      target .pickedPoint .length   = 0;
      target .intersections .length = 0;
      target .modelMatrix .assign (modelMatrix);
   },
   process ()
   {
      for (const modelMatrix of this .modelMatrices)
         ModelMatrixCache .push (modelMatrix);

      this .modelMatrices .length = 0;
      this .targets .size         = 0;
   },
});

Object .defineProperties (X3DPickSensorNode, external_X_ITE_X3D_X3DNode_default().getStaticProperties ("X3DPickSensorNode", "Picking", 1));

const X3DPickSensorNode_default_ = X3DPickSensorNode;
;

/* harmony default export */ const Picking_X3DPickSensorNode = (external_X_ITE_X3D_Namespace_default().add ("X3DPickSensorNode", X3DPickSensorNode_default_));
;// external "__X_ITE_X3D__ .X3DGeometryNode"
const external_X_ITE_X3D_X3DGeometryNode_namespaceObject = __X_ITE_X3D__ .X3DGeometryNode;
var external_X_ITE_X3D_X3DGeometryNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DGeometryNode_namespaceObject);
;// external "__X_ITE_X3D__ .X3DCast"
const external_X_ITE_X3D_X3DCast_namespaceObject = __X_ITE_X3D__ .X3DCast;
var external_X_ITE_X3D_X3DCast_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DCast_namespaceObject);
;// external "__X_ITE_X3D__ .Vector3"
const external_X_ITE_X3D_Vector3_namespaceObject = __X_ITE_X3D__ .Vector3;
var external_X_ITE_X3D_Vector3_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Vector3_namespaceObject);
;// external "__X_ITE_X3D__ .Vector4"
const external_X_ITE_X3D_Vector4_namespaceObject = __X_ITE_X3D__ .Vector4;
var external_X_ITE_X3D_Vector4_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Vector4_namespaceObject);
;// external "__X_ITE_X3D__ .Box3"
const external_X_ITE_X3D_Box3_namespaceObject = __X_ITE_X3D__ .Box3;
var external_X_ITE_X3D_Box3_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Box3_namespaceObject);
;// external "__X_ITE_X3D__ .Line3"
const external_X_ITE_X3D_Line3_namespaceObject = __X_ITE_X3D__ .Line3;
var external_X_ITE_X3D_Line3_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Line3_namespaceObject);
;// ./src/x_ite/Components/Picking/LinePickSensor.js















function LinePickSensor (executionContext)
{
   Picking_X3DPickSensorNode .call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).LinePickSensor);
}

Object .assign (Object .setPrototypeOf (LinePickSensor .prototype, Picking_X3DPickSensorNode .prototype),
{
   initialize ()
   {
      Picking_X3DPickSensorNode .prototype .initialize .call (this);

      this ._pickingGeometry .addInterest ("set_pickingGeometry__", this);

      this .set_pickingGeometry__ ();
   },
   set_pickingGeometry__ ()
   {
      this .pickingGeometryNode = external_X_ITE_X3D_X3DCast_default() ((external_X_ITE_X3D_X3DConstants_default()).IndexedLineSet, this ._pickingGeometry)
         ?? external_X_ITE_X3D_X3DCast_default() ((external_X_ITE_X3D_X3DConstants_default()).LineSet, this ._pickingGeometry);
   },
   process: (() =>
   {
      const
         pickingBBox             = new (external_X_ITE_X3D_Box3_default()) (),
         targetBBox              = new (external_X_ITE_X3D_Box3_default()) (),
         pickingCenter           = new (external_X_ITE_X3D_Vector3_default()) (),
         targetCenter            = new (external_X_ITE_X3D_Vector3_default()) (),
         matrix                  = new (external_X_ITE_X3D_Matrix4_default()) (),
         point1                  = new (external_X_ITE_X3D_Vector3_default()) (),
         point2                  = new (external_X_ITE_X3D_Vector3_default()) (),
         line                    = new (external_X_ITE_X3D_Line3_default()) (),
         a                       = new (external_X_ITE_X3D_Vector3_default()) (),
         b                       = new (external_X_ITE_X3D_Vector3_default()) (),
         intersections           = [ ],
         texCoord                = new (external_X_ITE_X3D_Vector3_default()) (),
         pickedTextureCoordinate = new (external_X_ITE_X3D_Fields_default()).MFVec3f (),
         pickedNormal            = new (external_X_ITE_X3D_Fields_default()).MFVec3f (),
         pickedPoint             = new (external_X_ITE_X3D_Fields_default()).MFVec3f ();

      return function ()
      {
         if (this .pickingGeometryNode)
         {
            const
               modelMatrices = this .getModelMatrices (),
               targets       = this .getTargets ();

            switch (this .getIntersectionType ())
            {
               case Picking_IntersectionType .BOUNDS:
               {
                  // Intersect bboxes.

                  for (const modelMatrix of modelMatrices)
                  {
                     pickingBBox .assign (this .pickingGeometryNode .getBBox ()) .multRight (modelMatrix);

                     for (const target of targets)
                     {
                        targetBBox .assign (target .geometryNode .getBBox ()) .multRight (target .modelMatrix);

                        if (pickingBBox .intersectsBox (targetBBox))
                        {
                           pickingCenter .assign (pickingBBox .center);
                           targetCenter  .assign (targetBBox .center);

                           target .intersected = true;
                           target .distance    = pickingCenter .distance (targetCenter);
                        }
                     }
                  }

                  // Send events.

                  const
                     pickedGeometries = this .getPickedGeometries (),
                     active           = !! pickedGeometries .length;

                  if (active !== this ._isActive .getValue ())
                     this ._isActive = active;

                  if (!this ._pickedGeometry .equals (pickedGeometries))
                     this ._pickedGeometry = pickedGeometries;

                  break;
               }
               case Picking_IntersectionType .GEOMETRY:
               {
                  // Intersect geometry.

                  for (const modelMatrix of modelMatrices)
                  {
                     pickingBBox .assign (this .pickingGeometryNode .getBBox ()) .multRight (modelMatrix);

                     for (const target of targets)
                     {
                        const
                           geometryNode = target .geometryNode,
                           vertices     = this .pickingGeometryNode .getVertices (),
                           numVertices  = vertices .length;

                        targetBBox .assign (geometryNode .getBBox ()) .multRight (target .modelMatrix);
                        matrix .assign (target .modelMatrix) .inverse () .multLeft (modelMatrix);

                        for (let v = 0; v < numVertices; v += 8)
                        {
                           matrix .multVecMatrix (point1 .set (vertices [v + 0], vertices [v + 1], vertices [v + 2]));
                           matrix .multVecMatrix (point2 .set (vertices [v + 4], vertices [v + 5], vertices [v + 6]));
                           line .setPoints (point1, point2);

                           intersections .length = 0;

                           if (geometryNode .intersectsLine (line, intersections))
                           {
                              for (const intersection of intersections)
                              {
                                 // Test if intersection.point is between point1 and point2.

                                 a .assign (intersection .point) .subtract (point1);
                                 b .assign (intersection .point) .subtract (point2);

                                 const
                                    c = a .add (b) .norm (),
                                    s = point1 .distance (point2);

                                 if (c <= s)
                                    target .intersections .push (intersection);
                              }
                           }
                        }

                        if (target .intersections .length)
                        {
                           pickingCenter .assign (pickingBBox .center);
                           targetCenter  .assign (targetBBox .center);

                           target .intersected = true;
                           target .distance    = pickingCenter .distance (targetCenter);
                        }
                     }
                  }

                  // Send events.

                  const
                     pickedGeometries = this .getPickedGeometries (),
                     active           = !! pickedGeometries .length;

                  pickedGeometries .assign (pickedGeometries .filter (node => node));

                  if (active !== this ._isActive .getValue ())
                     this ._isActive = active;

                  if (!this ._pickedGeometry .equals (pickedGeometries))
                     this ._pickedGeometry = pickedGeometries;

                  const pickedTargets = this .getPickedTargets ();

                  pickedTextureCoordinate .length = 0;
                  pickedNormal            .length = 0;
                  pickedPoint             .length = 0;

                  for (const pickedTarget of pickedTargets)
                  {
                     const pickedIntersections = pickedTarget .intersections;

                     for (const intersection of pickedIntersections)
                     {
                        const t = intersection .texCoord;

                        texCoord .set (t .x, t .y, t .z) .divide (t .w);

                        pickedTextureCoordinate .push (texCoord);
                        pickedNormal            .push (intersection .normal);
                        pickedPoint             .push (intersection .point);
                     }
                  }

                  if (!this ._pickedTextureCoordinate .equals (pickedTextureCoordinate))
                     this ._pickedTextureCoordinate = pickedTextureCoordinate;

                  if (!this ._pickedNormal .equals (pickedNormal))
                     this ._pickedNormal = pickedNormal;

                  if (!this ._pickedPoint .equals (pickedPoint))
                     this ._pickedPoint = pickedPoint;

                  break;
               }
            }
         }

         Picking_X3DPickSensorNode .prototype .process .call (this);
      };
   })(),
});

Object .defineProperties (LinePickSensor,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("LinePickSensor", "Picking", 1, "children", "3.2"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "metadata",                new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "description",             new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "enabled",                 new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "objectType",              new (external_X_ITE_X3D_Fields_default()).MFString ("ALL")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "matchCriterion",          new (external_X_ITE_X3D_Fields_default()).SFString ("MATCH_ANY")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "intersectionType",        new (external_X_ITE_X3D_Fields_default()).SFString ("BOUNDS")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "sortOrder",               new (external_X_ITE_X3D_Fields_default()).SFString ("CLOSEST")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "pickingGeometry",         new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "pickTarget",              new (external_X_ITE_X3D_Fields_default()).MFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "isActive",                new (external_X_ITE_X3D_Fields_default()).SFBool ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "pickedTextureCoordinate", new (external_X_ITE_X3D_Fields_default()).MFVec3f ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "pickedNormal",            new (external_X_ITE_X3D_Fields_default()).MFVec3f ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "pickedPoint",             new (external_X_ITE_X3D_Fields_default()).MFVec3f ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "pickedGeometry",          new (external_X_ITE_X3D_Fields_default()).MFNode ()),
      ]),
      enumerable: true,
   },
});

Object .assign ((external_X_ITE_X3D_X3DGeometryNode_default()).prototype,
{
   intersectsLine: (() =>
   {
      const
         invModelViewMatrix = new (external_X_ITE_X3D_Matrix4_default()) (),
         uvt                = { u: 0, v: 0, t: 0 },
         v0                 = new (external_X_ITE_X3D_Vector3_default()) (),
         v1                 = new (external_X_ITE_X3D_Vector3_default()) (),
         v2                 = new (external_X_ITE_X3D_Vector3_default()) ();

      return function (hitRay, intersections)
      {
         if (!this .intersectsBBox (hitRay))
            return intersections .length;

         // Apply transformations from geometry primitives and Text with ScreenFontStyle.
         hitRay .multLineMatrix (invModelViewMatrix .assign (this .getMatrix ()) .inverse ());

         const
            texCoords   = this .multiTexCoords [0] .getValue (),
            normals     = this .normals .getValue (),
            vertices    = this .vertices .getValue (),
            vertexCount = this .vertexCount;

         for (let i = 0; i < vertexCount; i += 3)
         {
            const i4 = i * 4;

            v0 .x = vertices [i4];     v0 .y = vertices [i4 + 1]; v0 .z = vertices [i4 +  2];
            v1 .x = vertices [i4 + 4]; v1 .y = vertices [i4 + 5]; v1 .z = vertices [i4 +  6];
            v2 .x = vertices [i4 + 8]; v2 .y = vertices [i4 + 9]; v2 .z = vertices [i4 + 10];

            if (!hitRay .intersectsTriangle (v0, v1, v2, uvt))
               continue;

            // Get barycentric coordinates.

            const { u, v, t } = uvt;

            // Determine vectors for LinePickSensor.

            const point = new (external_X_ITE_X3D_Vector3_default()) (u * vertices [i4]     + v * vertices [i4 + 4] + t * vertices [i4 +  8],
                                       u * vertices [i4 + 1] + v * vertices [i4 + 5] + t * vertices [i4 +  9],
                                       u * vertices [i4 + 2] + v * vertices [i4 + 6] + t * vertices [i4 + 10]);

            const texCoord = new (external_X_ITE_X3D_Vector4_default()) (u * texCoords [i4]     + v * texCoords [i4 + 4] + t * texCoords [i4 + 8],
                                          u * texCoords [i4 + 1] + v * texCoords [i4 + 5] + t * texCoords [i4 + 9],
                                          u * texCoords [i4 + 2] + v * texCoords [i4 + 6] + t * texCoords [i4 + 10],
                                          u * texCoords [i4 + 3] + v * texCoords [i4 + 7] + t * texCoords [i4 + 11]);

            const i3 = i * 3;

            const normal = new (external_X_ITE_X3D_Vector3_default()) (u * normals [i3]     + v * normals [i3 + 3] + t * normals [i3 + 6],
                                          u * normals [i3 + 1] + v * normals [i3 + 4] + t * normals [i3 + 7],
                                          u * normals [i3 + 2] + v * normals [i3 + 5] + t * normals [i3 + 8]);

            intersections .push ({ texCoord, normal, point: this .getMatrix () .multVecMatrix (point) });
         }

         return intersections .length;
      };
   })(),
   intersectsBBox: (() =>
   {
      const intersection = new (external_X_ITE_X3D_Vector3_default()) ();

      return function (hitRay)
      {
         const { min, max, planes } = this;

         const
            minX = min .x,
            maxX = max .x,
            minY = min .y,
            maxY = max .y,
            minZ = min .z,
            maxZ = max .z;

         // front
         if (planes [0] .intersectsLine (hitRay, intersection))
         {
            if (intersection .x >= minX && intersection .x <= maxX &&
                intersection .y >= minY && intersection .y <= maxY)
               return true;
         }

         // back
         if (planes [1] .intersectsLine (hitRay, intersection))
         {
            if (intersection .x >= minX && intersection .x <= maxX &&
                intersection .y >= minY && intersection .y <= maxY)
               return true;
         }

         // top
         if (planes [2] .intersectsLine (hitRay, intersection))
         {
            if (intersection .x >= minX && intersection .x <= maxX &&
                intersection .z >= minZ && intersection .z <= maxZ)
               return true;
         }

         // bottom
         if (planes [3] .intersectsLine (hitRay, intersection))
         {
            if (intersection .x >= minX && intersection .x <= maxX &&
                intersection .z >= minZ && intersection .z <= maxZ)
               return true;
         }

         // right
         if (planes [4] .intersectsLine (hitRay, intersection))
         {
            if (intersection .y >= minY && intersection .y <= maxY &&
                intersection .z >= minZ && intersection .z <= maxZ)
               return true;
         }

         return false;
      };
   })(),
});

const LinePickSensor_default_ = LinePickSensor;
;

/* harmony default export */ const Picking_LinePickSensor = (external_X_ITE_X3D_Namespace_default().add ("LinePickSensor", LinePickSensor_default_));
;// external "__X_ITE_X3D__ .X3DGroupingNode"
const external_X_ITE_X3D_X3DGroupingNode_namespaceObject = __X_ITE_X3D__ .X3DGroupingNode;
var external_X_ITE_X3D_X3DGroupingNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DGroupingNode_namespaceObject);
;// ./src/x_ite/Components/Picking/X3DPickableObject.js



function X3DPickableObject (executionContext)
{
   this .addType ((external_X_ITE_X3D_X3DConstants_default()).X3DPickableObject);

   // Private properties

   this .objectType = new Set ();
}

Object .assign (X3DPickableObject .prototype,
{
   initialize ()
   {
      this ._objectType .addInterest ("set_objectType__", this);

      this .set_objectType__ ();
   },
   getObjectType ()
   {
      return this .objectType;
   },
   set_objectType__ ()
   {
      this .objectType .clear ();

      for (const objectType of this ._objectType)
         this .objectType .add (objectType);
   },
   dispose ()
   { },
});

Object .defineProperties (X3DPickableObject, external_X_ITE_X3D_X3DNode_default().getStaticProperties ("X3DPickableObject", "Picking", 1));

const X3DPickableObject_default_ = X3DPickableObject;
;

/* harmony default export */ const Picking_X3DPickableObject = (external_X_ITE_X3D_Namespace_default().add ("X3DPickableObject", X3DPickableObject_default_));
;// external "__X_ITE_X3D__ .TraverseType"
const external_X_ITE_X3D_TraverseType_namespaceObject = __X_ITE_X3D__ .TraverseType;
var external_X_ITE_X3D_TraverseType_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_TraverseType_namespaceObject);
;// ./src/x_ite/Components/Picking/PickableGroup.js










function PickableGroup (executionContext)
{
   external_X_ITE_X3D_X3DGroupingNode_default().call (this, executionContext);
   Picking_X3DPickableObject .call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).PickableGroup);

   // Private properties

   this .pickSensorNodes = new Set ();
}

Object .assign (Object .setPrototypeOf (PickableGroup .prototype, (external_X_ITE_X3D_X3DGroupingNode_default()).prototype),
   Picking_X3DPickableObject .prototype,
{
   initialize ()
   {
      external_X_ITE_X3D_X3DGroupingNode_default().prototype .initialize .call (this);
      Picking_X3DPickableObject .prototype .initialize .call (this);

      this ._pickable .addInterest ("set_pickableObjects__", this);
   },
   set_pickableObjects__ ()
   {
      this .setPickableObject (this ._pickable .getValue () || this .getTransformSensors () .size);
   },
   traverse (type, renderObject)
   {
      if (type !== (external_X_ITE_X3D_TraverseType_default()).PICKING)
      {
         external_X_ITE_X3D_X3DGroupingNode_default().prototype .traverse .call (this, type, renderObject);
         return;
      }

      if (!this ._pickable .getValue ())
      {
         if (this .getTransformSensors () .size)
         {
            const modelMatrix = renderObject .getModelViewMatrix () .get ();

            for (const transformSensorNode of this .getTransformSensors ())
               transformSensorNode .collect (modelMatrix);
         }

         return;
      }

      if (this .getObjectType () .has ("NONE"))
         return;

      const
         browser       = this .getBrowser (),
         pickableStack = browser .getPickable ();

      if (this .getObjectType () .has ("ALL"))
      {
         pickableStack .push (true);
         external_X_ITE_X3D_X3DGroupingNode_default().prototype .traverse .call (this, type, renderObject);
         pickableStack .pop ();
         return;
      }

      // Filter pick sensors.

      const
         pickSensorNodes = this .pickSensorNodes,
         pickSensorStack = browser .getPickSensors ();

      for (const pickSensorNode of pickSensorStack .at (-1))
      {
         if (!pickSensorNode .getObjectType () .has ("ALL"))
         {
            let intersection = 0;

            for (const objectType of this .getObjectType ())
            {
               if (pickSensorNode .getObjectType () .has (objectType))
               {
                  ++ intersection;
                  break;
               }
            }

            switch (pickSensorNode .getMatchCriterion ())
            {
               case Picking_MatchCriterion .MATCH_ANY:
               {
                  if (intersection === 0)
                     continue;

                  break;
               }
               case Picking_MatchCriterion .MATCH_EVERY:
               {
                  if (intersection !== pickSensorNode .getObjectType () .size)
                     continue;

                  break;
               }
               case Picking_MatchCriterion .MATCH_ONLY_ONE:
               {
                  if (intersection !== 1)
                     continue;

                  break;
               }
            }
         }

         pickSensorNodes .add (pickSensorNode);
      }

      pickableStack   .push (true);
      pickSensorStack .push (pickSensorNodes);

      external_X_ITE_X3D_X3DGroupingNode_default().prototype .traverse .call (this, type, renderObject);

      pickSensorStack .pop ();
      pickableStack   .pop ();

      pickSensorNodes .clear ();
   },
   dispose ()
   {
      Picking_X3DPickableObject .prototype .dispose .call (this);
      external_X_ITE_X3D_X3DGroupingNode_default().prototype .dispose .call (this);
   },
});

Object .defineProperties (PickableGroup,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("PickableGroup", "Picking", 1, "children", "3.2"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "metadata",       new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "description",    new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "pickable",       new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "objectType",     new (external_X_ITE_X3D_Fields_default()).MFString ("ALL")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "visible",        new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "bboxDisplay",    new (external_X_ITE_X3D_Fields_default()).SFBool ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "bboxSize",       new (external_X_ITE_X3D_Fields_default()).SFVec3f (-1, -1, -1)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "bboxCenter",     new (external_X_ITE_X3D_Fields_default()).SFVec3f ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOnly,      "addChildren",    new (external_X_ITE_X3D_Fields_default()).MFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOnly,      "removeChildren", new (external_X_ITE_X3D_Fields_default()).MFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "children",       new (external_X_ITE_X3D_Fields_default()).MFNode ()),
      ]),
      enumerable: true,
   },
});

const PickableGroup_default_ = PickableGroup;
;

/* harmony default export */ const Picking_PickableGroup = (external_X_ITE_X3D_Namespace_default().add ("PickableGroup", PickableGroup_default_));
;// external "__X_ITE_X3D__ .Rotation4"
const external_X_ITE_X3D_Rotation4_namespaceObject = __X_ITE_X3D__ .Rotation4;
var external_X_ITE_X3D_Rotation4_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Rotation4_namespaceObject);
;// external "__X_ITE_X3D__ .AmmoClass"
const external_X_ITE_X3D_AmmoClass_namespaceObject = __X_ITE_X3D__ .AmmoClass;
var external_X_ITE_X3D_AmmoClass_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_AmmoClass_namespaceObject);
;// ./src/x_ite/Browser/Picking/VolumePicker.js





function VolumePicker ()
{
   this .broadphase             = new (external_X_ITE_X3D_AmmoClass_default()).btDbvtBroadphase ();
   this .collisionConfiguration = new (external_X_ITE_X3D_AmmoClass_default()).btDefaultCollisionConfiguration ();
   this .dispatcher             = new (external_X_ITE_X3D_AmmoClass_default()).btCollisionDispatcher (this .collisionConfiguration);
   this .collisionWorld         = new (external_X_ITE_X3D_AmmoClass_default()).btCollisionWorld (this .dispatcher, this .broadphase, this .collisionConfiguration);

   this .compoundShape1         = new (external_X_ITE_X3D_AmmoClass_default()).btCompoundShape ();
   this .motionState1           = new (external_X_ITE_X3D_AmmoClass_default()).btDefaultMotionState ();
   this .constructionInfo1      = new (external_X_ITE_X3D_AmmoClass_default()).btRigidBodyConstructionInfo (0, this .motionState1, this .compoundShape1);
   this .rigidBody1             = new (external_X_ITE_X3D_AmmoClass_default()).btRigidBody (this .constructionInfo1);

   this .compoundShape2         = new (external_X_ITE_X3D_AmmoClass_default()).btCompoundShape ();
   this .motionState2           = new (external_X_ITE_X3D_AmmoClass_default()).btDefaultMotionState ();
   this .constructionInfo2      = new (external_X_ITE_X3D_AmmoClass_default()).btRigidBodyConstructionInfo (0, this .motionState2, this .compoundShape2);
   this .rigidBody2             = new (external_X_ITE_X3D_AmmoClass_default()).btRigidBody (this .constructionInfo2);

   this .collisionWorld .addCollisionObject (this .rigidBody1);
   this .collisionWorld .addCollisionObject (this .rigidBody2);
}

Object .assign (VolumePicker .prototype,
{
   constuctor: VolumePicker,
   setChildShape1 (matrix, childShape)
   {
      this .setChildShape (this .compoundShape1, matrix, childShape);
   },
   setChildShape2 (matrix, childShape)
   {
      this .setChildShape (this .compoundShape2, matrix, childShape);
   },
   setChildShape1Components (transform, localScaling, childShape)
   {
      this .setChildShapeComponents (this .compoundShape1, transform, localScaling, childShape);
   },
   setChildShape2Components (transform, localScaling, childShape)
   {
      this .setChildShapeComponents (this .compoundShape2, transform, localScaling, childShape);
   },
   setChildShape: (() =>
   {
      const
         translation = new (external_X_ITE_X3D_Vector3_default()) (),
         rotation    = new (external_X_ITE_X3D_Rotation4_default()) (),
         scale       = new (external_X_ITE_X3D_Vector3_default()) (),
         s           = new (external_X_ITE_X3D_AmmoClass_default()).btVector3 (0, 0, 0);

      return function (compoundShape, matrix, childShape)
      {
         if (compoundShape .getNumChildShapes ())
            compoundShape .removeChildShapeByIndex (0);

         if (childShape .getNumChildShapes ())
         {
            matrix .getTransform (translation, rotation, scale);

            s .setValue (scale .x, scale .y, scale .z);

            childShape .setLocalScaling (s);
            compoundShape .addChildShape (this .getTransform (translation, rotation), childShape);
         }
      };
   })(),
   setChildShapeComponents (compoundShape, transform, localScaling, childShape)
   {
      if (compoundShape .getNumChildShapes ())
         compoundShape .removeChildShapeByIndex (0);

      if (childShape .getNumChildShapes ())
      {
         childShape .setLocalScaling (localScaling);
         compoundShape .addChildShape (transform, childShape);
      }
   },
   contactTest ()
   {
      this .collisionWorld .performDiscreteCollisionDetection ();

      const numManifolds = this .dispatcher .getNumManifolds ();

      for (let i = 0; i < numManifolds; ++ i)
      {
         const
            contactManifold = this .dispatcher .getManifoldByIndexInternal (i),
            numContacts     = contactManifold .getNumContacts ();

         for (let j = 0; j < numContacts; ++ j)
         {
            const pt = contactManifold .getContactPoint (j);

            if (pt .getDistance () <= 0)
               return true;
         }
      }

      return false;
   },
   getTransform: (() =>
   {
      const
         T = new (external_X_ITE_X3D_AmmoClass_default()).btTransform (),
         o = new (external_X_ITE_X3D_AmmoClass_default()).btVector3 (0, 0, 0),
         m = new (external_X_ITE_X3D_Matrix4_default()) ();

      return function (translation, rotation, transform)
      {
         const t = transform || T;

         m .setTransform (translation, rotation);

         o .setValue (m [12], m [13], m [14]);

         t .getBasis () .setValue (m [0], m [4], m [8],
                                   m [1], m [5], m [9],
                                   m [2], m [6], m [10]);

         t .setOrigin (o);

         return t;
      };
   })(),
});

const VolumePicker_default_ = VolumePicker;
;

/* harmony default export */ const Picking_VolumePicker = (external_X_ITE_X3D_Namespace_default().add ("VolumePicker", VolumePicker_default_));
;// ./src/x_ite/Components/Picking/PointPickSensor.js














function PointPickSensor (executionContext)
{
   Picking_X3DPickSensorNode .call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).PointPickSensor);

   // Private properties

   this .picker         = new Picking_VolumePicker ();
   this .compoundShapes = [ ];
}

Object .assign (Object .setPrototypeOf (PointPickSensor .prototype, Picking_X3DPickSensorNode .prototype),
{
   initialize ()
   {
      Picking_X3DPickSensorNode .prototype .initialize .call (this);

      this ._pickingGeometry .addInterest ("set_pickingGeometry__", this);

      this .set_pickingGeometry__ ();
   },
   set_pickingGeometry__ ()
   {
      this .pickingGeometryNode ?._rebuild .removeInterest ("set_geometry__", this);

      this .pickingGeometryNode = external_X_ITE_X3D_X3DCast_default() ((external_X_ITE_X3D_X3DConstants_default()).PointSet, this ._pickingGeometry);

      this .pickingGeometryNode ?._rebuild .addInterest ("set_geometry__", this);

      this .set_geometry__ ();
   },
   set_geometry__: (() =>
   {
      const
         defaultScale = new (external_X_ITE_X3D_AmmoClass_default()).btVector3 (1, 1, 1),
         o            = new (external_X_ITE_X3D_AmmoClass_default()).btVector3 (),
         t            = new (external_X_ITE_X3D_AmmoClass_default()).btTransform ();

      return function ()
      {
         const
            compoundShapes = this .compoundShapes,
            coord          = this .pickingGeometryNode ?.getCoord (),
            length         = coord ?.getSize () ?? 0;

         for (let i = 0; i < length; ++ i)
         {
            if (i < compoundShapes .length)
            {
               const
                  compoundShape = compoundShapes [i],
                  point         = coord .get1Point (i, compoundShape .point);

               o .setValue (point .x, point .y, point .z);
               t .setOrigin (o);

               compoundShape .setLocalScaling (defaultScale);
               compoundShape .updateChildTransform (0, t);
            }
            else
            {
               const
                  compoundShape = new (external_X_ITE_X3D_AmmoClass_default()).btCompoundShape (),
                  sphereShape   = new (external_X_ITE_X3D_AmmoClass_default()).btSphereShape (0),
                  point         = coord .get1Point (i, new (external_X_ITE_X3D_Vector3_default()) ());

               compoundShape .point = point;

               o .setValue (point .x, point .y, point .z);
               t .setOrigin (o);

               compoundShape .addChildShape (t, sphereShape);
               compoundShapes .push (compoundShape);
            }
         }

         compoundShapes .length = length;
      };
   })(),
   process: (() =>
   {
      const
         pickingBBox   = new (external_X_ITE_X3D_Box3_default()) (),
         targetBBox    = new (external_X_ITE_X3D_Box3_default()) (),
         pickingCenter = new (external_X_ITE_X3D_Vector3_default()) (),
         targetCenter  = new (external_X_ITE_X3D_Vector3_default()) (),
         transform     = new (external_X_ITE_X3D_AmmoClass_default()).btTransform (),
         localScaling  = new (external_X_ITE_X3D_AmmoClass_default()).btVector3 (),
         translation   = new (external_X_ITE_X3D_Vector3_default()) (),
         rotation      = new (external_X_ITE_X3D_Rotation4_default()) (),
         scale         = new (external_X_ITE_X3D_Vector3_default()) (),
         pickedPoint   = new (external_X_ITE_X3D_Fields_default()).MFVec3f ();

      return function ()
      {
         if (this .pickingGeometryNode)
         {
            const
               modelMatrices = this .getModelMatrices (),
               targets       = this .getTargets ();

            switch (this .getIntersectionType ())
            {
               case Picking_IntersectionType .BOUNDS:
               {
                  // Intersect bboxes.

                  for (const modelMatrix of modelMatrices)
                  {
                     pickingBBox .assign (this .pickingGeometryNode .getBBox ()) .multRight (modelMatrix);

                     for (const target of targets)
                     {
                        targetBBox .assign (target .geometryNode .getBBox ()) .multRight (target .modelMatrix);

                        if (pickingBBox .intersectsBox (targetBBox))
                        {
                           pickingCenter .assign (pickingBBox .center);
                           targetCenter  .assign (targetBBox .center);

                           target .intersected = true;
                           target .distance    = pickingCenter .distance (targetCenter);
                        }
                     }
                  }

                  // Send events.

                  const
                     pickedGeometries = this .getPickedGeometries (),
                     active           = !! pickedGeometries .length;

                  pickedGeometries .assign (pickedGeometries .filter (node => node));

                  if (active !== this ._isActive .getValue ())
                     this ._isActive = active;

                  if (!this ._pickedGeometry .equals (pickedGeometries))
                     this ._pickedGeometry = pickedGeometries;

                  break;
               }
               case Picking_IntersectionType .GEOMETRY:
               {
                  // Intersect geometry.

                  const
                     picker         = this .picker,
                     compoundShapes = this .compoundShapes;

                  for (const modelMatrix of modelMatrices)
                  {
                     pickingBBox .assign (this .pickingGeometryNode .getBBox ()) .multRight (modelMatrix);

                     modelMatrix .getTransform (translation, rotation, scale);

                     picker .getTransform (translation, rotation, transform);
                     localScaling .setValue (scale .x, scale .y, scale .z);

                     for (const compoundShape of compoundShapes)
                     {
                        picker .setChildShape1Components (transform, localScaling, compoundShape);

                        for (const target of targets)
                        {
                           const targetShape = this .getPickShape (target .geometryNode);

                           targetBBox .assign (target .geometryNode .getBBox ()) .multRight (target .modelMatrix);

                           picker .setChildShape2 (target .modelMatrix, targetShape .getCompoundShape ());

                           if (picker .contactTest ())
                           {
                              pickingCenter .assign (pickingBBox .center);
                              targetCenter  .assign (targetBBox .center);

                              target .intersected = true;
                              target .distance    = pickingCenter .distance (targetCenter);
                              target .pickedPoint .push (compoundShape .point);
                           }
                        }
                     }
                  }

                  // Send events.

                  const
                     pickedGeometries = this .getPickedGeometries (),
                     active           = !! pickedGeometries .length;

                  pickedGeometries .assign (pickedGeometries .filter (node => node));

                  if (active !== this ._isActive .getValue ())
                     this ._isActive = active;

                  if (!this ._pickedGeometry .equals (pickedGeometries))
                     this ._pickedGeometry = pickedGeometries;

                  const pickedTargets = this .getPickedTargets ();

                  pickedPoint .length = 0;

                  for (const pickedTarget of pickedTargets)
                  {
                     for (const pp of pickedTarget .pickedPoint)
                        pickedPoint .push (pp);
                  }

                  if (!this ._pickedPoint .equals (pickedPoint))
                     this ._pickedPoint = pickedPoint;

                  break;
               }
            }
         }

         Picking_X3DPickSensorNode .prototype .process .call (this);
      };
   })(),
});

Object .defineProperties (PointPickSensor,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("PointPickSensor", "Picking", 1, "children", "3.2"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "metadata",         new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "description",      new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "enabled",          new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "objectType",       new (external_X_ITE_X3D_Fields_default()).MFString ("ALL")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "matchCriterion",   new (external_X_ITE_X3D_Fields_default()).SFString ("MATCH_ANY")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "intersectionType", new (external_X_ITE_X3D_Fields_default()).SFString ("BOUNDS")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "sortOrder",        new (external_X_ITE_X3D_Fields_default()).SFString ("CLOSEST")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "pickingGeometry",  new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "pickTarget",       new (external_X_ITE_X3D_Fields_default()).MFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "isActive",         new (external_X_ITE_X3D_Fields_default()).SFBool ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "pickedPoint",      new (external_X_ITE_X3D_Fields_default()).MFVec3f ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "pickedGeometry",   new (external_X_ITE_X3D_Fields_default()).MFNode ()),
      ]),
      enumerable: true,
   },
});

const PointPickSensor_default_ = PointPickSensor;
;

/* harmony default export */ const Picking_PointPickSensor = (external_X_ITE_X3D_Namespace_default().add ("PointPickSensor", PointPickSensor_default_));
;// ./src/x_ite/Components/Picking/PrimitivePickSensor.js











function PrimitivePickSensor (executionContext)
{
   Picking_X3DPickSensorNode .call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).PrimitivePickSensor);

   // Private properties

   this .picker = new Picking_VolumePicker ();
}

Object .assign (Object .setPrototypeOf (PrimitivePickSensor .prototype, Picking_X3DPickSensorNode .prototype),
{
   initialize ()
   {
      Picking_X3DPickSensorNode .prototype .initialize .call (this);

      this ._pickingGeometry .addInterest ("set_pickingGeometry__", this);

      this .set_pickingGeometry__ ();
   },
   set_pickingGeometry__ ()
   {
      this .pickingGeometryNode = null;

      try
      {
         const
            node = this ._pickingGeometry .getValue () .getInnerNode (),
            type = node .getType ();

         for (let t = type .length - 1; t >= 0; -- t)
         {
            switch (type [t])
            {
               case (external_X_ITE_X3D_X3DConstants_default()).Box:
               case (external_X_ITE_X3D_X3DConstants_default()).Cone:
               case (external_X_ITE_X3D_X3DConstants_default()).Cylinder:
               case (external_X_ITE_X3D_X3DConstants_default()).Sphere:
               {
                  this .pickingGeometryNode = node;
                  break;
               }
               default:
                  continue;
            }

            break;
         }
      }
      catch
      { }
   },
   process: (() =>
   {
      const
         pickingBBox   = new (external_X_ITE_X3D_Box3_default()) (),
         targetBBox    = new (external_X_ITE_X3D_Box3_default()) (),
         pickingCenter = new (external_X_ITE_X3D_Vector3_default()) (),
         targetCenter  = new (external_X_ITE_X3D_Vector3_default()) ();

      return function ()
      {
         if (this .pickingGeometryNode)
         {
            const
               modelMatrices = this .getModelMatrices (),
               targets       = this .getTargets ();

            switch (this .getIntersectionType ())
            {
               case Picking_IntersectionType .BOUNDS:
               {
                  // Intersect bboxes.

                  for (const modelMatrix of modelMatrices)
                  {
                     pickingBBox .assign (this .pickingGeometryNode .getBBox ()) .multRight (modelMatrix);

                     for (const target of targets)
                     {
                        targetBBox .assign (target .geometryNode .getBBox ()) .multRight (target .modelMatrix);

                        if (pickingBBox .intersectsBox (targetBBox))
                        {
                           pickingCenter .assign (pickingBBox .center);
                           targetCenter  .assign (targetBBox .center);

                           target .intersected = true;
                           target .distance    = pickingCenter .distance (targetCenter);
                        }
                     }
                  }

                  // Send events.

                  const
                     pickedGeometries = this .getPickedGeometries (),
                     active           = !! pickedGeometries .length;

                  pickedGeometries .assign (pickedGeometries .filter (node => node));

                  if (active !== this ._isActive .getValue ())
                     this ._isActive = active;

                  if (!this ._pickedGeometry .equals (pickedGeometries))
                     this ._pickedGeometry = pickedGeometries;

                  break;
               }
               case Picking_IntersectionType .GEOMETRY:
               {
                  // Intersect geometry.

                  const picker = this .picker;

                  for (const modelMatrix of modelMatrices)
                  {
                     const pickingShape = this .getPickShape (this .pickingGeometryNode);

                     pickingBBox .assign (this .pickingGeometryNode .getBBox ()) .multRight (modelMatrix);

                     picker .setChildShape1 (modelMatrix, pickingShape .getCompoundShape ());

                     for (const target of targets)
                     {
                        const targetShape = this .getPickShape (target .geometryNode);

                        targetBBox .assign (target .geometryNode .getBBox ()) .multRight (target .modelMatrix);

                        picker .setChildShape2 (target .modelMatrix, targetShape .getCompoundShape ());

                        if (picker .contactTest ())
                        {
                           pickingCenter .assign (pickingBBox .center);
                           targetCenter  .assign (targetBBox .center);

                           target .intersected = true;
                           target .distance    = pickingCenter .distance (targetCenter);
                        }
                     }
                  }

                  // Send events.

                  const
                     pickedGeometries = this .getPickedGeometries (),
                     active           = !! pickedGeometries .length;

                  pickedGeometries .assign (pickedGeometries .filter (node => node));

                  if (active !== this ._isActive .getValue ())
                     this ._isActive = active;

                  if (!this ._pickedGeometry .equals (pickedGeometries))
                     this ._pickedGeometry = pickedGeometries;

                  break;
               }
            }
         }

         Picking_X3DPickSensorNode .prototype .process .call (this);
      };
   })(),
});

Object .defineProperties (PrimitivePickSensor,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("PrimitivePickSensor", "Picking", 2, "children", "3.2"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "metadata",         new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "description",      new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "enabled",          new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "objectType",       new (external_X_ITE_X3D_Fields_default()).MFString ("ALL")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "matchCriterion",   new (external_X_ITE_X3D_Fields_default()).SFString ("MATCH_ANY")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "intersectionType", new (external_X_ITE_X3D_Fields_default()).SFString ("BOUNDS")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "sortOrder",        new (external_X_ITE_X3D_Fields_default()).SFString ("CLOSEST")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "pickingGeometry",  new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "pickTarget",       new (external_X_ITE_X3D_Fields_default()).MFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "isActive",         new (external_X_ITE_X3D_Fields_default()).SFBool ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "pickedGeometry",   new (external_X_ITE_X3D_Fields_default()).MFNode ()),
      ]),
      enumerable: true,
   },
});

const PrimitivePickSensor_default_ = PrimitivePickSensor;
;

/* harmony default export */ const Picking_PrimitivePickSensor = (external_X_ITE_X3D_Namespace_default().add ("PrimitivePickSensor", PrimitivePickSensor_default_));
;// ./src/x_ite/Components/Picking/VolumePickSensor.js












function VolumePickSensor (executionContext)
{
   Picking_X3DPickSensorNode .call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).VolumePickSensor);

   // Private properties

   this .picker = new Picking_VolumePicker ();
}

Object .assign (Object .setPrototypeOf (VolumePickSensor .prototype, Picking_X3DPickSensorNode .prototype),
{
   initialize ()
   {
      Picking_X3DPickSensorNode .prototype .initialize .call (this);

      this ._pickingGeometry .addInterest ("set_pickingGeometry__", this);

      this .set_pickingGeometry__ ();
   },
   set_pickingGeometry__ ()
   {
      this .pickingGeometryNode = external_X_ITE_X3D_X3DCast_default() ((external_X_ITE_X3D_X3DConstants_default()).X3DGeometryNode, this ._pickingGeometry);
   },
   process: (() =>
   {
      const
         pickingBBox   = new (external_X_ITE_X3D_Box3_default()) (),
         targetBBox    = new (external_X_ITE_X3D_Box3_default()) (),
         pickingCenter = new (external_X_ITE_X3D_Vector3_default()) (),
         targetCenter  = new (external_X_ITE_X3D_Vector3_default()) ();

      return function ()
      {
         if (this .pickingGeometryNode)
         {
            const
               modelMatrices = this .getModelMatrices (),
               targets       = this .getTargets ();

            switch (this .getIntersectionType ())
            {
               case Picking_IntersectionType .BOUNDS:
               {
                  // Intersect bboxes.

                  for (const modelMatrix of modelMatrices)
                  {
                     pickingBBox .assign (this .pickingGeometryNode .getBBox ()) .multRight (modelMatrix);

                     for (const target of targets)
                     {
                        targetBBox .assign (target .geometryNode .getBBox ()) .multRight (target .modelMatrix);

                        if (pickingBBox .intersectsBox (targetBBox))
                        {
                           pickingCenter .assign (pickingBBox .center);
                           targetCenter  .assign (targetBBox .center);

                           target .intersected = true;
                           target .distance    = pickingCenter .distance (targetCenter);
                        }
                     }
                  }

                  // Send events.

                  const
                     pickedGeometries = this .getPickedGeometries (),
                     active           = !! pickedGeometries .length;

                  pickedGeometries .assign (pickedGeometries .filter (node => node));

                  if (active !== this ._isActive .getValue ())
                     this ._isActive = active;

                  if (!this ._pickedGeometry .equals (pickedGeometries))
                     this ._pickedGeometry = pickedGeometries;

                  break;
               }
               case Picking_IntersectionType .GEOMETRY:
               {
                  // Intersect geometry.

                  const picker = this .picker;

                  for (const modelMatrix of modelMatrices)
                  {
                     const pickingShape = this .getPickShape (this .pickingGeometryNode);

                     pickingBBox .assign (this .pickingGeometryNode .getBBox ()) .multRight (modelMatrix);

                     picker .setChildShape1 (modelMatrix, pickingShape .getCompoundShape ());

                     for (const target of targets)
                     {
                        const targetShape = this .getPickShape (target .geometryNode);

                        targetBBox .assign (target .geometryNode .getBBox ()) .multRight (target .modelMatrix);

                        picker .setChildShape2 (target .modelMatrix, targetShape .getCompoundShape ());

                        if (picker .contactTest ())
                        {
                           pickingCenter .assign (pickingBBox .center);
                           targetCenter  .assign (targetBBox .center);

                           target .intersected = true;
                           target .distance    = pickingCenter .distance (targetCenter);
                        }
                     }
                  }

                  // Send events.

                  const
                     pickedGeometries = this .getPickedGeometries (),
                     active           = !! pickedGeometries .length;

                  pickedGeometries .assign (pickedGeometries .filter (node => node));

                  if (active !== this ._isActive .getValue ())
                     this ._isActive = active;

                  if (!this ._pickedGeometry .equals (pickedGeometries))
                     this ._pickedGeometry = pickedGeometries;

                  break;
               }
            }
         }

         Picking_X3DPickSensorNode .prototype .process .call (this);
      };
   })(),
});

Object .defineProperties (VolumePickSensor,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("VolumePickSensor", "Picking", 3, "children", "3.2"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "metadata",         new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "description",      new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "enabled",          new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "objectType",       new (external_X_ITE_X3D_Fields_default()).MFString ("ALL")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "matchCriterion",   new (external_X_ITE_X3D_Fields_default()).SFString ("MATCH_ANY")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "intersectionType", new (external_X_ITE_X3D_Fields_default()).SFString ("BOUNDS")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "sortOrder",        new (external_X_ITE_X3D_Fields_default()).SFString ("CLOSEST")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "pickingGeometry",  new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "pickTarget",       new (external_X_ITE_X3D_Fields_default()).MFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "isActive",         new (external_X_ITE_X3D_Fields_default()).SFBool ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).outputOnly,     "pickedGeometry",   new (external_X_ITE_X3D_Fields_default()).MFNode ()),
      ]),
      enumerable: true,
   },
});

const VolumePickSensor_default_ = VolumePickSensor;
;

/* harmony default export */ const Picking_VolumePickSensor = (external_X_ITE_X3D_Namespace_default().add ("VolumePickSensor", VolumePickSensor_default_));
;// ./src/assets/components/PickingComponent.js









external_X_ITE_X3D_Components_default().add ({
   name: "Picking",
   concreteNodes:
   [
      Picking_LinePickSensor,
      Picking_PickableGroup,
      Picking_PointPickSensor,
      Picking_PrimitivePickSensor,
      Picking_VolumePickSensor,
   ],
   abstractNodes:
   [
      Picking_X3DPickSensorNode,
      Picking_X3DPickableObject,
   ],
});

const PickingComponent_default_ = undefined;
;

/* harmony default export */ const PickingComponent = (external_X_ITE_X3D_Namespace_default().add ("PickingComponent", PickingComponent_default_));
/******/ })()
;