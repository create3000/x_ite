/* X_ITE v16.1.0 */
const __X_ITE_X3D__ = window [Symbol .for ("X_ITE.X3D")];
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	const __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			const getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/

// UNUSED EXPORTS: default

;// external "__X_ITE_X3D__ .Components"
const external_X_ITE_X3D_Components_namespaceObject = __X_ITE_X3D__ .Components;
var external_X_ITE_X3D_Components_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Components_namespaceObject);
;// external "__X_ITE_X3D__ .Fields"
const external_X_ITE_X3D_Fields_namespaceObject = __X_ITE_X3D__ .Fields;
var external_X_ITE_X3D_Fields_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Fields_namespaceObject);
;// external "__X_ITE_X3D__ .X3DFieldDefinition"
const external_X_ITE_X3D_X3DFieldDefinition_namespaceObject = __X_ITE_X3D__ .X3DFieldDefinition;
var external_X_ITE_X3D_X3DFieldDefinition_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DFieldDefinition_namespaceObject);
;// external "__X_ITE_X3D__ .FieldDefinitionArray"
const external_X_ITE_X3D_FieldDefinitionArray_namespaceObject = __X_ITE_X3D__ .FieldDefinitionArray;
var external_X_ITE_X3D_FieldDefinitionArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_FieldDefinitionArray_namespaceObject);
;// external "__X_ITE_X3D__ .X3DNode"
const external_X_ITE_X3D_X3DNode_namespaceObject = __X_ITE_X3D__ .X3DNode;
var external_X_ITE_X3D_X3DNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DNode_namespaceObject);
;// external "__X_ITE_X3D__ .X3DLayerNode"
const external_X_ITE_X3D_X3DLayerNode_namespaceObject = __X_ITE_X3D__ .X3DLayerNode;
var external_X_ITE_X3D_X3DLayerNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DLayerNode_namespaceObject);
;// external "__X_ITE_X3D__ .Viewpoint"
const external_X_ITE_X3D_Viewpoint_namespaceObject = __X_ITE_X3D__ .Viewpoint;
var external_X_ITE_X3D_Viewpoint_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Viewpoint_namespaceObject);
;// external "__X_ITE_X3D__ .Group"
const external_X_ITE_X3D_Group_namespaceObject = __X_ITE_X3D__ .Group;
var external_X_ITE_X3D_Group_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Group_namespaceObject);
;// external "__X_ITE_X3D__ .X3DConstants"
const external_X_ITE_X3D_X3DConstants_namespaceObject = __X_ITE_X3D__ .X3DConstants;
var external_X_ITE_X3D_X3DConstants_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DConstants_namespaceObject);
;// external "__X_ITE_X3D__ .Namespace"
const external_X_ITE_X3D_Namespace_namespaceObject = __X_ITE_X3D__ .Namespace;
var external_X_ITE_X3D_Namespace_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Namespace_namespaceObject);
;// ./src/x_ite/Components/Annotation/AnnotationLayer.js









function AnnotationLayer (executionContext)
{
   external_X_ITE_X3D_X3DLayerNode_default().call (this,
                       executionContext,
                       new (external_X_ITE_X3D_Viewpoint_default()) (executionContext),
                       new (external_X_ITE_X3D_Group_default()) (executionContext));

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).AnnotationLayer);
}

Object .assign (Object .setPrototypeOf (AnnotationLayer .prototype, (external_X_ITE_X3D_X3DLayerNode_default()).prototype),
{
   initialize ()
   {
      external_X_ITE_X3D_X3DLayerNode_default().prototype .initialize .call (this);
   },
});

Object .defineProperties (AnnotationLayer,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("AnnotationLayer", "Annotation", 1, "layers", "4.0"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "metadata",     new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "isPickable",   new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "layoutPolicy", new (external_X_ITE_X3D_Fields_default()).MFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "shownGroupID", new (external_X_ITE_X3D_Fields_default()).MFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "viewport",     new (external_X_ITE_X3D_Fields_default()).SFNode ()),
      ]),
      enumerable: true,
   },
});

const __default__ = AnnotationLayer;
;

/* harmony default export */ const Annotation_AnnotationLayer = (external_X_ITE_X3D_Namespace_default().add ("AnnotationLayer", __default__));
;// external "__X_ITE_X3D__ .X3DChildNode"
const external_X_ITE_X3D_X3DChildNode_namespaceObject = __X_ITE_X3D__ .X3DChildNode;
var external_X_ITE_X3D_X3DChildNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DChildNode_namespaceObject);
;// ./src/x_ite/Components/Annotation/AnnotationTarget.js







function AnnotationTarget (executionContext)
{
   external_X_ITE_X3D_X3DChildNode_default().call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).AnnotationTarget);
}

Object .assign (Object .setPrototypeOf (AnnotationTarget .prototype, (external_X_ITE_X3D_X3DChildNode_default()).prototype),
{
   initialize ()
   {
      external_X_ITE_X3D_X3DChildNode_default().prototype .initialize .call (this);
   },
});

Object .defineProperties (AnnotationTarget,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("AnnotationTarget", "Annotation", 1, "children", "4.0"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "metadata",       new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "referencePoint", new (external_X_ITE_X3D_Fields_default()).SFVec3f ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "leadLineStyle",  new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "marker",         new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "annotations",    new (external_X_ITE_X3D_Fields_default()).MFNode ()),
      ]),
      enumerable: true,
   },
});

const AnnotationTarget_default_ = AnnotationTarget;
;

/* harmony default export */ const Annotation_AnnotationTarget = (external_X_ITE_X3D_Namespace_default().add ("AnnotationTarget", AnnotationTarget_default_));
;// external "__X_ITE_X3D__ .X3DGroupingNode"
const external_X_ITE_X3D_X3DGroupingNode_namespaceObject = __X_ITE_X3D__ .X3DGroupingNode;
var external_X_ITE_X3D_X3DGroupingNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DGroupingNode_namespaceObject);
;// ./src/x_ite/Components/Annotation/X3DAnnotationNode.js




function X3DAnnotationNode (executionContext)
{
   external_X_ITE_X3D_X3DChildNode_default().call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).X3DAnnotationNode);
}

Object .assign (Object .setPrototypeOf (X3DAnnotationNode .prototype, (external_X_ITE_X3D_X3DChildNode_default()).prototype),
{
   initialize ()
   {
      external_X_ITE_X3D_X3DChildNode_default().prototype .initialize .call (this);
   },
});

Object .defineProperties (X3DAnnotationNode, external_X_ITE_X3D_X3DNode_default().getStaticProperties ("X3DAnnotationNode", "Annotation", 1));

const X3DAnnotationNode_default_ = X3DAnnotationNode;
;

/* harmony default export */ const Annotation_X3DAnnotationNode = (external_X_ITE_X3D_Namespace_default().add ("X3DAnnotationNode", X3DAnnotationNode_default_));
;// ./src/x_ite/Components/Annotation/GroupAnnotation.js








function GroupAnnotation (executionContext)
{
   external_X_ITE_X3D_X3DGroupingNode_default().call (this, executionContext);
   Annotation_X3DAnnotationNode .call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).GroupAnnotation);
}

Object .assign (Object .setPrototypeOf (GroupAnnotation .prototype, (external_X_ITE_X3D_X3DGroupingNode_default()).prototype),
   Annotation_X3DAnnotationNode .prototype,
{
   initialize ()
   {
      external_X_ITE_X3D_X3DGroupingNode_default().prototype .initialize .call (this);
      Annotation_X3DAnnotationNode .prototype .initialize .call (this);
   },
   dispose ()
   {
      Annotation_X3DAnnotationNode .prototype .dispose .call (this);
      external_X_ITE_X3D_X3DGroupingNode_default().prototype .dispose .call (this);
   },
});

Object .defineProperties (GroupAnnotation,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("GroupAnnotation", "Annotation", 1, "children", "4.0"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "metadata",          new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "enabled",           new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "annotationGroupID", new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "displayPolicy",     new (external_X_ITE_X3D_Fields_default()).SFString ("NEVER")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "visible",           new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "bboxDisplay",       new (external_X_ITE_X3D_Fields_default()).SFBool ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "bboxSize",          new (external_X_ITE_X3D_Fields_default()).SFVec3f (-1, -1, -1)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "bboxCenter",        new (external_X_ITE_X3D_Fields_default()).SFVec3f ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOnly,      "addChildren",       new (external_X_ITE_X3D_Fields_default()).MFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOnly,      "removeChildren",    new (external_X_ITE_X3D_Fields_default()).MFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "children",          new (external_X_ITE_X3D_Fields_default()).MFNode ()),
      ]),
      enumerable: true,
   },
});

const GroupAnnotation_default_ = GroupAnnotation;
;

/* harmony default export */ const Annotation_GroupAnnotation = (external_X_ITE_X3D_Namespace_default().add ("GroupAnnotation", GroupAnnotation_default_));
;// external "__X_ITE_X3D__ .X3DUrlObject"
const external_X_ITE_X3D_X3DUrlObject_namespaceObject = __X_ITE_X3D__ .X3DUrlObject;
var external_X_ITE_X3D_X3DUrlObject_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DUrlObject_namespaceObject);
;// ./src/x_ite/Components/Annotation/IconAnnotation.js








function IconAnnotation (executionContext)
{
   Annotation_X3DAnnotationNode .call (this, executionContext);
   external_X_ITE_X3D_X3DUrlObject_default().call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).IconAnnotation);
}

Object .assign (Object .setPrototypeOf (IconAnnotation .prototype, Annotation_X3DAnnotationNode .prototype),
   (external_X_ITE_X3D_X3DUrlObject_default()).prototype,
{
   initialize ()
   {
      Annotation_X3DAnnotationNode .prototype .initialize .call (this);
      external_X_ITE_X3D_X3DUrlObject_default().prototype .initialize .call (this);
   },
   async requestImmediateLoad (cache = true)
   { },
   dispose ()
   {
      external_X_ITE_X3D_X3DUrlObject_default().prototype .dispose .call (this);
      Annotation_X3DAnnotationNode .prototype .dispose .call (this);
   },
});

Object .defineProperties (IconAnnotation,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("IconAnnotation", "Annotation", 1, "children", "4.0"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "metadata",             new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "enabled",              new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "annotationGroupID",    new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "displayPolicy",        new (external_X_ITE_X3D_Fields_default()).SFString ("NEVER")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "url",                  new (external_X_ITE_X3D_Fields_default()).MFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "autoRefresh",          new (external_X_ITE_X3D_Fields_default()).SFTime (0)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "autoRefreshTimeLimit", new (external_X_ITE_X3D_Fields_default()).SFTime (3600)),
      ]),
      enumerable: true,
   },
});

const IconAnnotation_default_ = IconAnnotation;
;

/* harmony default export */ const Annotation_IconAnnotation = (external_X_ITE_X3D_Namespace_default().add ("IconAnnotation", IconAnnotation_default_));
;// ./src/x_ite/Components/Annotation/TextAnnotation.js







function TextAnnotation (executionContext)
{
   Annotation_X3DAnnotationNode .call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).TextAnnotation);
}

Object .assign (Object .setPrototypeOf (TextAnnotation .prototype, Annotation_X3DAnnotationNode .prototype),
{
   initialize ()
   {
      Annotation_X3DAnnotationNode .prototype .initialize .call (this);
   },
});

Object .defineProperties (TextAnnotation,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("TextAnnotation", "Annotation", 1, "children", "4.0"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "metadata",          new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "enabled",           new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "annotationGroupID", new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "displayPolicy",     new (external_X_ITE_X3D_Fields_default()).SFString ("NEVER")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "contentType",       new (external_X_ITE_X3D_Fields_default()).SFString ("text/plain")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "text",              new (external_X_ITE_X3D_Fields_default()).SFString ()),
      ]),
      enumerable: true,
   },
});

const TextAnnotation_default_ = TextAnnotation;
;

/* harmony default export */ const Annotation_TextAnnotation = (external_X_ITE_X3D_Namespace_default().add ("TextAnnotation", TextAnnotation_default_));
;// ./src/x_ite/Components/Annotation/URLAnnotation.js







function URLAnnotation (executionContext)
{
   Annotation_X3DAnnotationNode .call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).URLAnnotation);
}

Object .assign (Object .setPrototypeOf (URLAnnotation .prototype, Annotation_X3DAnnotationNode .prototype),
{
   initialize ()
   {
      Annotation_X3DAnnotationNode .prototype .initialize .call (this);
   },
});

Object .defineProperties (URLAnnotation,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("URLAnnotation", "Annotation", 1, "children", "4.0"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "metadata",          new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "enabled",           new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "annotationGroupID", new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "displayPolicy",     new (external_X_ITE_X3D_Fields_default()).SFString ("NEVER")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput, "url",               new (external_X_ITE_X3D_Fields_default()).MFString ()),
      ]),
      enumerable: true,
   },
});

const URLAnnotation_default_ = URLAnnotation;
;

/* harmony default export */ const Annotation_URLAnnotation = (external_X_ITE_X3D_Namespace_default().add ("URLAnnotation", URLAnnotation_default_));
;// ./src/assets/components/AnnotationComponent.js









external_X_ITE_X3D_Components_default().add ({
   name: "Annotation",
   concreteNodes:
   [
      Annotation_AnnotationLayer,
      Annotation_AnnotationTarget,
      Annotation_GroupAnnotation,
      Annotation_IconAnnotation,
      Annotation_TextAnnotation,
      Annotation_URLAnnotation,
   ],
   abstractNodes:
   [
      Annotation_X3DAnnotationNode,
   ],
});

const AnnotationComponent_default_ = undefined;
;

/* harmony default export */ const AnnotationComponent = (external_X_ITE_X3D_Namespace_default().add ("AnnotationComponent", AnnotationComponent_default_));
/******/ })()
;