/* X_ITE v16.1.1 */
const __X_ITE_X3D__ = window [Symbol .for ("X_ITE.X3D")];
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	const __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			const getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/

// UNUSED EXPORTS: default

;// external "__X_ITE_X3D__ .Components"
const external_X_ITE_X3D_Components_namespaceObject = __X_ITE_X3D__ .Components;
var external_X_ITE_X3D_Components_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Components_namespaceObject);
;// external "__X_ITE_X3D__ .X3DBaseNode"
const external_X_ITE_X3D_X3DBaseNode_namespaceObject = __X_ITE_X3D__ .X3DBaseNode;
var external_X_ITE_X3D_X3DBaseNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DBaseNode_namespaceObject);
;// external "__X_ITE_X3D__ .X3DFieldDefinition"
const external_X_ITE_X3D_X3DFieldDefinition_namespaceObject = __X_ITE_X3D__ .X3DFieldDefinition;
var external_X_ITE_X3D_X3DFieldDefinition_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DFieldDefinition_namespaceObject);
;// external "__X_ITE_X3D__ .FieldDefinitionArray"
const external_X_ITE_X3D_FieldDefinitionArray_namespaceObject = __X_ITE_X3D__ .FieldDefinitionArray;
var external_X_ITE_X3D_FieldDefinitionArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_FieldDefinitionArray_namespaceObject);
;// external "__X_ITE_X3D__ .X3DField"
const external_X_ITE_X3D_X3DField_namespaceObject = __X_ITE_X3D__ .X3DField;
var external_X_ITE_X3D_X3DField_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DField_namespaceObject);
;// external "__X_ITE_X3D__ .X3DArrayField"
const external_X_ITE_X3D_X3DArrayField_namespaceObject = __X_ITE_X3D__ .X3DArrayField;
var external_X_ITE_X3D_X3DArrayField_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DArrayField_namespaceObject);
;// external "__X_ITE_X3D__ .Fields"
const external_X_ITE_X3D_Fields_namespaceObject = __X_ITE_X3D__ .Fields;
var external_X_ITE_X3D_Fields_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Fields_namespaceObject);
;// external "__X_ITE_X3D__ .X3DBrowser"
const external_X_ITE_X3D_X3DBrowser_namespaceObject = __X_ITE_X3D__ .X3DBrowser;
var external_X_ITE_X3D_X3DBrowser_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DBrowser_namespaceObject);
;// external "__X_ITE_X3D__ .ComponentInfo"
const external_X_ITE_X3D_ComponentInfo_namespaceObject = __X_ITE_X3D__ .ComponentInfo;
var external_X_ITE_X3D_ComponentInfo_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_ComponentInfo_namespaceObject);
;// external "__X_ITE_X3D__ .ComponentInfoArray"
const external_X_ITE_X3D_ComponentInfoArray_namespaceObject = __X_ITE_X3D__ .ComponentInfoArray;
var external_X_ITE_X3D_ComponentInfoArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_ComponentInfoArray_namespaceObject);
;// external "__X_ITE_X3D__ .ProfileInfo"
const external_X_ITE_X3D_ProfileInfo_namespaceObject = __X_ITE_X3D__ .ProfileInfo;
var external_X_ITE_X3D_ProfileInfo_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_ProfileInfo_namespaceObject);
;// external "__X_ITE_X3D__ .ProfileInfoArray"
const external_X_ITE_X3D_ProfileInfoArray_namespaceObject = __X_ITE_X3D__ .ProfileInfoArray;
var external_X_ITE_X3D_ProfileInfoArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_ProfileInfoArray_namespaceObject);
;// external "__X_ITE_X3D__ .ConcreteNodesArray"
const external_X_ITE_X3D_ConcreteNodesArray_namespaceObject = __X_ITE_X3D__ .ConcreteNodesArray;
var external_X_ITE_X3D_ConcreteNodesArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_ConcreteNodesArray_namespaceObject);
;// external "__X_ITE_X3D__ .AbstractNodesArray"
const external_X_ITE_X3D_AbstractNodesArray_namespaceObject = __X_ITE_X3D__ .AbstractNodesArray;
var external_X_ITE_X3D_AbstractNodesArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_AbstractNodesArray_namespaceObject);
;// external "__X_ITE_X3D__ .UnitInfo"
const external_X_ITE_X3D_UnitInfo_namespaceObject = __X_ITE_X3D__ .UnitInfo;
var external_X_ITE_X3D_UnitInfo_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_UnitInfo_namespaceObject);
;// external "__X_ITE_X3D__ .UnitInfoArray"
const external_X_ITE_X3D_UnitInfoArray_namespaceObject = __X_ITE_X3D__ .UnitInfoArray;
var external_X_ITE_X3D_UnitInfoArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_UnitInfoArray_namespaceObject);
;// external "__X_ITE_X3D__ .NamedNodesArray"
const external_X_ITE_X3D_NamedNodesArray_namespaceObject = __X_ITE_X3D__ .NamedNodesArray;
var external_X_ITE_X3D_NamedNodesArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_NamedNodesArray_namespaceObject);
;// external "__X_ITE_X3D__ .ImportedNodesArray"
const external_X_ITE_X3D_ImportedNodesArray_namespaceObject = __X_ITE_X3D__ .ImportedNodesArray;
var external_X_ITE_X3D_ImportedNodesArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_ImportedNodesArray_namespaceObject);
;// external "__X_ITE_X3D__ .X3DImportedNode"
const external_X_ITE_X3D_X3DImportedNode_namespaceObject = __X_ITE_X3D__ .X3DImportedNode;
var external_X_ITE_X3D_X3DImportedNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DImportedNode_namespaceObject);
;// external "__X_ITE_X3D__ .ExportedNodesArray"
const external_X_ITE_X3D_ExportedNodesArray_namespaceObject = __X_ITE_X3D__ .ExportedNodesArray;
var external_X_ITE_X3D_ExportedNodesArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_ExportedNodesArray_namespaceObject);
;// external "__X_ITE_X3D__ .X3DExportedNode"
const external_X_ITE_X3D_X3DExportedNode_namespaceObject = __X_ITE_X3D__ .X3DExportedNode;
var external_X_ITE_X3D_X3DExportedNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DExportedNode_namespaceObject);
;// external "__X_ITE_X3D__ .X3DExecutionContext"
const external_X_ITE_X3D_X3DExecutionContext_namespaceObject = __X_ITE_X3D__ .X3DExecutionContext;
var external_X_ITE_X3D_X3DExecutionContext_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DExecutionContext_namespaceObject);
;// external "__X_ITE_X3D__ .X3DScene"
const external_X_ITE_X3D_X3DScene_namespaceObject = __X_ITE_X3D__ .X3DScene;
var external_X_ITE_X3D_X3DScene_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DScene_namespaceObject);
;// external "__X_ITE_X3D__ .ExternProtoDeclarationArray"
const external_X_ITE_X3D_ExternProtoDeclarationArray_namespaceObject = __X_ITE_X3D__ .ExternProtoDeclarationArray;
var external_X_ITE_X3D_ExternProtoDeclarationArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_ExternProtoDeclarationArray_namespaceObject);
;// external "__X_ITE_X3D__ .ProtoDeclarationArray"
const external_X_ITE_X3D_ProtoDeclarationArray_namespaceObject = __X_ITE_X3D__ .ProtoDeclarationArray;
var external_X_ITE_X3D_ProtoDeclarationArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_ProtoDeclarationArray_namespaceObject);
;// external "__X_ITE_X3D__ .X3DExternProtoDeclaration"
const external_X_ITE_X3D_X3DExternProtoDeclaration_namespaceObject = __X_ITE_X3D__ .X3DExternProtoDeclaration;
var external_X_ITE_X3D_X3DExternProtoDeclaration_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DExternProtoDeclaration_namespaceObject);
;// external "__X_ITE_X3D__ .X3DProtoDeclaration"
const external_X_ITE_X3D_X3DProtoDeclaration_namespaceObject = __X_ITE_X3D__ .X3DProtoDeclaration;
var external_X_ITE_X3D_X3DProtoDeclaration_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DProtoDeclaration_namespaceObject);
;// external "__X_ITE_X3D__ .X3DProtoDeclarationNode"
const external_X_ITE_X3D_X3DProtoDeclarationNode_namespaceObject = __X_ITE_X3D__ .X3DProtoDeclarationNode;
var external_X_ITE_X3D_X3DProtoDeclarationNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DProtoDeclarationNode_namespaceObject);
;// external "__X_ITE_X3D__ .RouteArray"
const external_X_ITE_X3D_RouteArray_namespaceObject = __X_ITE_X3D__ .RouteArray;
var external_X_ITE_X3D_RouteArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_RouteArray_namespaceObject);
;// external "__X_ITE_X3D__ .X3DRoute"
const external_X_ITE_X3D_X3DRoute_namespaceObject = __X_ITE_X3D__ .X3DRoute;
var external_X_ITE_X3D_X3DRoute_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DRoute_namespaceObject);
;// external "__X_ITE_X3D__ .Namespace"
const external_X_ITE_X3D_Namespace_namespaceObject = __X_ITE_X3D__ .Namespace;
var external_X_ITE_X3D_Namespace_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Namespace_namespaceObject);
;// ./src/x_ite/Browser/Scripting/evaluate.js
function evaluate (thisArg, globalObject, sourceText)
{
   return new Function (/* js */ `with (arguments [0])
   {
      return eval ((() =>
      {
         const sourceText = arguments [1];

         delete arguments [0];
         delete arguments [1];

         arguments .length = 0;

         return sourceText;
      })
      ());
   }`)
   .call (thisArg, globalObject, sourceText);
}

const __default__ = evaluate;
;

/* harmony default export */ const Scripting_evaluate = (external_X_ITE_X3D_Namespace_default().add ("evaluate", __default__));
;// external "__X_ITE_X3D__ .X3DNode"
const external_X_ITE_X3D_X3DNode_namespaceObject = __X_ITE_X3D__ .X3DNode;
var external_X_ITE_X3D_X3DNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DNode_namespaceObject);
;// external "__X_ITE_X3D__ .X3DChildNode"
const external_X_ITE_X3D_X3DChildNode_namespaceObject = __X_ITE_X3D__ .X3DChildNode;
var external_X_ITE_X3D_X3DChildNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DChildNode_namespaceObject);
;// external "__X_ITE_X3D__ .X3DUrlObject"
const external_X_ITE_X3D_X3DUrlObject_namespaceObject = __X_ITE_X3D__ .X3DUrlObject;
var external_X_ITE_X3D_X3DUrlObject_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DUrlObject_namespaceObject);
;// external "__X_ITE_X3D__ .X3DConstants"
const external_X_ITE_X3D_X3DConstants_namespaceObject = __X_ITE_X3D__ .X3DConstants;
var external_X_ITE_X3D_X3DConstants_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DConstants_namespaceObject);
;// ./src/x_ite/Components/Scripting/X3DScriptNode.js





function X3DScriptNode (executionContext)
{
   external_X_ITE_X3D_X3DChildNode_default().call (this, executionContext);
   external_X_ITE_X3D_X3DUrlObject_default().call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).X3DScriptNode);
}

Object .assign (Object .setPrototypeOf (X3DScriptNode .prototype, (external_X_ITE_X3D_X3DChildNode_default()).prototype),
   (external_X_ITE_X3D_X3DUrlObject_default()).prototype,
{
   initialize ()
   {
      external_X_ITE_X3D_X3DChildNode_default().prototype .initialize .call (this);
      external_X_ITE_X3D_X3DUrlObject_default().prototype .initialize .call (this);
   },
   dispose ()
   {
      external_X_ITE_X3D_X3DUrlObject_default().prototype .dispose .call (this);
      external_X_ITE_X3D_X3DChildNode_default().prototype .dispose .call (this);
   },
});

Object .defineProperties (X3DScriptNode, external_X_ITE_X3D_X3DNode_default().getStaticProperties ("X3DScriptNode", "Scripting", 1));

const X3DScriptNode_default_ = X3DScriptNode;
;

/* harmony default export */ const Scripting_X3DScriptNode = (external_X_ITE_X3D_Namespace_default().add ("X3DScriptNode", X3DScriptNode_default_));
;// external "__X_ITE_X3D__ .FileLoader"
const external_X_ITE_X3D_FileLoader_namespaceObject = __X_ITE_X3D__ .FileLoader;
var external_X_ITE_X3D_FileLoader_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_FileLoader_namespaceObject);
;// external "__X_ITE_X3D__ .SFNodeCache"
const external_X_ITE_X3D_SFNodeCache_namespaceObject = __X_ITE_X3D__ .SFNodeCache;
var external_X_ITE_X3D_SFNodeCache_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_SFNodeCache_namespaceObject);
;// external "__X_ITE_X3D__ .helper"
const external_X_ITE_X3D_helper_namespaceObject = __X_ITE_X3D__ .helper;
var external_X_ITE_X3D_helper_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_helper_namespaceObject);
;// ./src/x_ite/Components/Scripting/Script.js





































function Script (executionContext)
{
   Scripting_X3DScriptNode .call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).Script);
}

Object .assign (Object .setPrototypeOf (Script .prototype, Scripting_X3DScriptNode .prototype),
{
   initialize ()
   {
      Scripting_X3DScriptNode .prototype .initialize .call (this);

      this .requestImmediateLoad () .catch (Function .prototype);
   },
   getExtendedEventHandling ()
   {
      return false;
   },
   canUserDefinedFields ()
   {
      return true;
   },
   addUserDefinedField (accessType, name, field)
   {
      Scripting_X3DScriptNode .prototype .addUserDefinedField .call (this, accessType, name, field);

      if (!this .isInitialized ())
         return;

      this .setLoadState ((external_X_ITE_X3D_X3DConstants_default()).NOT_STARTED_STATE);
      this .requestImmediateLoad () .catch (Function .prototype);
   },
   removeUserDefinedField (name)
   {
      this .getUserDefinedFields () .get (name) ?.removeInterest ("set_field__", this);

      Scripting_X3DScriptNode .prototype .removeUserDefinedField .call (this, name);

      if (!this .isInitialized ())
         return;

      this .setLoadState ((external_X_ITE_X3D_X3DConstants_default()).NOT_STARTED_STATE);
      this .requestImmediateLoad () .catch (Function .prototype);
   },
   getSourceText ()
   {
      return this ._url;
   },
   async unloadData ()
   {
      // Call shutdown and disconnect.

      this .shutdown ?.();

      window .removeEventListener ("unload", this .shutdown);

      this .shutdown = null;

      // Disconnect prepareEvents.

      this .getBrowser () .prepareEvents () .removeInterest ("call__", this);

      // Disconnect eventsProcessed.

      this .removeInterest ("call__", this);

      // Disconnect fields.

      for (const field of this .getUserDefinedFields ())
         field .removeInterest ("set_field__", this);
   },
   async loadData ()
   {
      // See: 29.2.2 Script execution
      // Wait a tick to get user-defined field with name 'self' working.
      await this .unloadData ();

      new (external_X_ITE_X3D_FileLoader_default()) (this) .loadDocument (this ._url, async data =>
      {
         if (data === null)
         {
            // No URL could be loaded.
            this .setLoadState ((external_X_ITE_X3D_X3DConstants_default()).FAILED_STATE);
         }
         else
         {
            await this .initialize__ (external_X_ITE_X3D_helper_default().decodeText (data));
            this .setLoadState ((external_X_ITE_X3D_X3DConstants_default()).COMPLETE_STATE);
         }
      });
   },
   createGlobalObject ()
   {
      const getScriptNode = () => this;

      const handler =
      {
         get (target, key, receiver)
         {
            switch (key)
            {
               case "getScriptNode":
                  return getScriptNode;
               case "currentScene":
                  return getScriptNode () .getExecutionContext ();
               default:
                  return Reflect .get (target, key, receiver);
            }
         },
      };

      const browser = new Proxy (this .getBrowser (), handler);

      function SFNode (vrmlSyntax)
      {
         const node = new (external_X_ITE_X3D_Fields_default()).SFNode ();

         node .fromString (vrmlSyntax, getScriptNode () .getExecutionContext ());

         if (node .getValue ())
            return external_X_ITE_X3D_SFNodeCache_default().get (node .getValue ());

         throw new Error ("SFNode.new: invalid argument.");
      }

      SFNode .prototype = (external_X_ITE_X3D_Fields_default()).SFNode .prototype;

      const globalObject =
      {
         NULL:  { value: null },
         FALSE: { value: false },
         TRUE:  { value: true },
         print: { value: browser .println .bind (browser) },
         trace: { value: browser .println .bind (browser) },

         Browser: { value: browser },

         X3DConstants:                { value: (external_X_ITE_X3D_X3DConstants_default()) },
         X3DBrowser:                  { value: (external_X_ITE_X3D_X3DBrowser_default()) },
         X3DExecutionContext:         { value: (external_X_ITE_X3D_X3DExecutionContext_default()) },
         X3DScene:                    { value: (external_X_ITE_X3D_X3DScene_default()) },
         ComponentInfo:               { value: (external_X_ITE_X3D_ComponentInfo_default()) },
         ComponentInfoArray:          { value: (external_X_ITE_X3D_ComponentInfoArray_default()) },
         ProfileInfo:                 { value: (external_X_ITE_X3D_ProfileInfo_default()) },
         ProfileInfoArray:            { value: (external_X_ITE_X3D_ProfileInfoArray_default()) },
         ConcreteNodesArray:          { value: (external_X_ITE_X3D_ConcreteNodesArray_default()) },          // non-standard
         AbstractNodesArray:          { value: (external_X_ITE_X3D_AbstractNodesArray_default()) },          // non-standard
         UnitInfo:                    { value: (external_X_ITE_X3D_UnitInfo_default()) },
         UnitInfoArray:               { value: (external_X_ITE_X3D_UnitInfoArray_default()) },
         NamedNodesArray:             { value: (external_X_ITE_X3D_NamedNodesArray_default()) },             // non-standard
         ImportedNodesArray:          { value: (external_X_ITE_X3D_ImportedNodesArray_default()) },          // non-standard
         X3DImportedNode:             { value: (external_X_ITE_X3D_X3DImportedNode_default()) },             // non-standard
         ExportedNodesArray:          { value: (external_X_ITE_X3D_ExportedNodesArray_default()) },          // non-standard
         X3DExportedNode:             { value: (external_X_ITE_X3D_X3DExportedNode_default()) },             // non-standard
         ExternProtoDeclarationArray: { value: (external_X_ITE_X3D_ExternProtoDeclarationArray_default()) },
         ProtoDeclarationArray:       { value: (external_X_ITE_X3D_ProtoDeclarationArray_default()) },
         X3DExternProtoDeclaration:   { value: (external_X_ITE_X3D_X3DExternProtoDeclaration_default()) },
         X3DProtoDeclaration:         { value: (external_X_ITE_X3D_X3DProtoDeclaration_default()) },
         X3DProtoDeclarationNode:     { value: (external_X_ITE_X3D_X3DProtoDeclarationNode_default()) },     // non-standard
         RouteArray:                  { value: (external_X_ITE_X3D_RouteArray_default()) },
         X3DRoute:                    { value: (external_X_ITE_X3D_X3DRoute_default()) },

         X3DBaseNode: { value: (external_X_ITE_X3D_X3DBaseNode_default()) },                                 // non-standard

         X3DFieldDefinition:   { value: (external_X_ITE_X3D_X3DFieldDefinition_default()) },
         FieldDefinitionArray: { value: (external_X_ITE_X3D_FieldDefinitionArray_default()) },

         X3DField:      { value: (external_X_ITE_X3D_X3DField_default()) },
         X3DArrayField: { value: (external_X_ITE_X3D_X3DArrayField_default()) },

         SFColor:       { value: (external_X_ITE_X3D_Fields_default()).SFColor },
         SFColorRGBA:   { value: (external_X_ITE_X3D_Fields_default()).SFColorRGBA },
         SFImage:       { value: (external_X_ITE_X3D_Fields_default()).SFImage },
         SFMatrix3d:    { value: (external_X_ITE_X3D_Fields_default()).SFMatrix3d },
         SFMatrix3f:    { value: (external_X_ITE_X3D_Fields_default()).SFMatrix3f },
         SFMatrix4d:    { value: (external_X_ITE_X3D_Fields_default()).SFMatrix4d },
         SFMatrix4f:    { value: (external_X_ITE_X3D_Fields_default()).SFMatrix4f },
         SFNode:        { value: SFNode },
         SFQuaternion:  { value: (external_X_ITE_X3D_Fields_default()).SFQuaternion },
         SFRotation:    { value: (external_X_ITE_X3D_Fields_default()).SFRotation },
         SFString:      { value: (external_X_ITE_X3D_Fields_default()).SFString },
         SFVec2d:       { value: (external_X_ITE_X3D_Fields_default()).SFVec2d },
         SFVec2f:       { value: (external_X_ITE_X3D_Fields_default()).SFVec2f },
         SFVec3d:       { value: (external_X_ITE_X3D_Fields_default()).SFVec3d },
         SFVec3f:       { value: (external_X_ITE_X3D_Fields_default()).SFVec3f },
         SFVec4d:       { value: (external_X_ITE_X3D_Fields_default()).SFVec4d },
         SFVec4f:       { value: (external_X_ITE_X3D_Fields_default()).SFVec4f },
         VrmlMatrix:    { value: (external_X_ITE_X3D_Fields_default()).VrmlMatrix },

         MFBool:        { value: (external_X_ITE_X3D_Fields_default()).MFBool },
         MFColor:       { value: (external_X_ITE_X3D_Fields_default()).MFColor },
         MFColorRGBA:   { value: (external_X_ITE_X3D_Fields_default()).MFColorRGBA },
         MFDouble:      { value: (external_X_ITE_X3D_Fields_default()).MFDouble },
         MFFloat:       { value: (external_X_ITE_X3D_Fields_default()).MFFloat },
         MFImage:       { value: (external_X_ITE_X3D_Fields_default()).MFImage },
         MFInt32:       { value: (external_X_ITE_X3D_Fields_default()).MFInt32 },
         MFMatrix3d:    { value: (external_X_ITE_X3D_Fields_default()).MFMatrix3d },
         MFMatrix3f:    { value: (external_X_ITE_X3D_Fields_default()).MFMatrix3f },
         MFMatrix4d:    { value: (external_X_ITE_X3D_Fields_default()).MFMatrix4d },
         MFMatrix4f:    { value: (external_X_ITE_X3D_Fields_default()).MFMatrix4f },
         MFNode:        { value: (external_X_ITE_X3D_Fields_default()).MFNode },
         MFQuaternion:  { value: (external_X_ITE_X3D_Fields_default()).MFQuaternion },
         MFRotation:    { value: (external_X_ITE_X3D_Fields_default()).MFRotation },
         MFString:      { value: (external_X_ITE_X3D_Fields_default()).MFString },
         MFTime:        { value: (external_X_ITE_X3D_Fields_default()).MFTime },
         MFVec2d:       { value: (external_X_ITE_X3D_Fields_default()).MFVec2d },
         MFVec2f:       { value: (external_X_ITE_X3D_Fields_default()).MFVec2f },
         MFVec3d:       { value: (external_X_ITE_X3D_Fields_default()).MFVec3d },
         MFVec3f:       { value: (external_X_ITE_X3D_Fields_default()).MFVec3f },
         MFVec4d:       { value: (external_X_ITE_X3D_Fields_default()).MFVec4d },
         MFVec4f:       { value: (external_X_ITE_X3D_Fields_default()).MFVec4f },
      };

      for (const field of this .getUserDefinedFields ())
      {
         if (field .getAccessType () === (external_X_ITE_X3D_X3DConstants_default()).inputOnly)
            continue;

         const names = [field .getName ()];

         if (field .getAccessType () === (external_X_ITE_X3D_X3DConstants_default()).inputOutput)
            names .push (field .getName () + "_changed");

         for (const name of names)
         {
            if (name in globalObject)
               continue;

            globalObject [name] =
            {
               get: field .valueOf .bind (field),
               set: field .setValue .bind (field),
            };
         }
      }

      return Object .create (Object .prototype, globalObject);
   },
   createContext (sourceText)
   {
      const callbacks = ["initialize", "prepareEvents", "eventsProcessed", "shutdown"];

      for (const field of this .getUserDefinedFields ())
      {
         switch (field .getAccessType ())
         {
            case (external_X_ITE_X3D_X3DConstants_default()).inputOnly:
               callbacks .push (field .getName ());
               break;
            case (external_X_ITE_X3D_X3DConstants_default()).inputOutput:
               callbacks .push ("set_" + field .getName ());
               break;
         }
      }

      // Add a \n immediately after sourceText, in case there is a comment in the last line.

      sourceText += "\n;\n[" + callbacks .map (c => `typeof ${c} !== "undefined" ? ${c} : undefined`) .join (",") + "];";

      const
         result  = this .evaluate (sourceText),
         context = new Map ();

      for (let i = 0; i < callbacks .length; ++ i)
         context .set (callbacks [i], result [i]);

      return context;
   },
   evaluate (sourceText)
   {
      this .globalObject ??= this .createGlobalObject ();

      return Scripting_evaluate (external_X_ITE_X3D_SFNodeCache_default().get (this), this .globalObject, sourceText);
   },
   async initialize__ (sourceText)
   {
      const browser = this .getBrowser ();

      // Create context.

      this .globalObject = this .createGlobalObject ();
      this .context      = this .createContext (sourceText);

      // Connect shutdown.

      const shutdown = this .context .get ("shutdown");

      if (typeof shutdown === "function")
      {
         this .shutdown = () =>
         {
            if (!browser .isContextLost ())
               this .call__ (shutdown, "shutdown");
         };

         window .addEventListener ("unload", this .shutdown, { once: true });
      }

      // Connect prepareEvents.

      const prepareEvents = this .context .get ("prepareEvents");

      if (typeof prepareEvents === "function")
         browser .prepareEvents () .addInterest ("call__", this, prepareEvents, "prepareEvents");

      // Connect eventsProcessed.

      const eventsProcessed = this .context .get ("eventsProcessed");

      if (typeof eventsProcessed === "function")
         this .addInterest ("call__", this, eventsProcessed, "eventsProcessed");

      // Connect fields.

      for (const field of this .getUserDefinedFields ())
      {
         switch (field .getAccessType ())
         {
            case (external_X_ITE_X3D_X3DConstants_default()).inputOnly:
            {
               const callback = this .context .get (field .getName ());

               if (typeof callback === "function")
                  field .addInterest ("set_field__", this, callback, [ ]);

               break;
            }
            case (external_X_ITE_X3D_X3DConstants_default()).inputOutput:
            {
               const callback = this .context .get ("set_" + field .getName ());

               if (typeof callback === "function")
                  field .addInterest ("set_field__", this, callback, [ ]);

               break;
            }
         }
      }

      // Call initialize function.

      const initialize = this .context .get ("initialize");

      if (typeof initialize === "function")
         await this .call__ (initialize, "initialize");
   },
   async call__ (callback, name)
   {
      try
      {
         await callback .call (external_X_ITE_X3D_SFNodeCache_default().get (this), this .getBrowser () .getCurrentTime ());
      }
      catch (error)
      {
         this .setError (`in function '${name}'`, error);
      }
   },
   async set_field__ (callback, cache, field)
   {
      const copy = cache .pop () ?? field .create ();

      try
      {
         copy .assign (field);

         await callback .call (external_X_ITE_X3D_SFNodeCache_default().get (this), copy .valueOf (), this .getBrowser () .getCurrentTime ());
      }
      catch (error)
      {
         this .setError (`in function '${field .getName ()}'`, error);
      }
      finally
      {
         cache .push (copy);
      }
   },
   setError (reason, error)
   {
      const worldURL = this .getExecutionContext () .getWorldURL () .startsWith ("data:")
         ? "data:"
         : this .getExecutionContext () .getWorldURL ();

      console .error (`JavaScript Error in Script '${this .getName ()}', ${reason}\nworld url is '${worldURL}':`);
      console .error (error);
   },
   dispose ()
   {
      this .unloadData ();

      Scripting_X3DScriptNode .prototype .dispose .call (this);
   },
});

Object .defineProperties (Script,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("Script", "Scripting", 1, "children", "2.0"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "metadata",             new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "description",          new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "load",                 new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "url",                  new (external_X_ITE_X3D_Fields_default()).MFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "autoRefresh",          new (external_X_ITE_X3D_Fields_default()).SFTime (0)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "autoRefreshTimeLimit", new (external_X_ITE_X3D_Fields_default()).SFTime (3600)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "directOutput",         new (external_X_ITE_X3D_Fields_default()).SFBool ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "mustEvaluate",         new (external_X_ITE_X3D_Fields_default()).SFBool ()),
      ]),
      enumerable: true,
   },
});

const Script_default_ = Script;
;

/* harmony default export */ const Scripting_Script = (external_X_ITE_X3D_Namespace_default().add ("Script", Script_default_));
;// ./src/assets/components/ScriptingComponent.js




external_X_ITE_X3D_Components_default().add ({
   name: "Scripting",
   concreteNodes:
   [
      Scripting_Script,
   ],
   abstractNodes:
   [
      Scripting_X3DScriptNode,
   ],
});

const ScriptingComponent_default_ = undefined;
;

/* harmony default export */ const ScriptingComponent = (external_X_ITE_X3D_Namespace_default().add ("ScriptingComponent", ScriptingComponent_default_));
/******/ })()
;