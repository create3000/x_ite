#version 300 es
precision highp float;
void
main () { }
