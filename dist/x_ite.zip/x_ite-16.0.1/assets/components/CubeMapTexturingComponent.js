/* X_ITE v16.0.1 */
const __X_ITE_X3D__ = window [Symbol .for ("X_ITE.X3D")];
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	const __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			const getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/

// UNUSED EXPORTS: default

;// external "__X_ITE_X3D__ .Components"
const external_X_ITE_X3D_Components_namespaceObject = __X_ITE_X3D__ .Components;
var external_X_ITE_X3D_Components_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Components_namespaceObject);
;// external "__X_ITE_X3D__ .Namespace"
const external_X_ITE_X3D_Namespace_namespaceObject = __X_ITE_X3D__ .Namespace;
var external_X_ITE_X3D_Namespace_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Namespace_namespaceObject);
;// ./src/x_ite/Browser/CubeMapTexturing/Panorama2.fs.js
const __default__ = /* glsl */ `#version 300 es
precision highp float;precision highp int;precision highp sampler2D;const float M_PI=3.1415926535897932384626433832795;in vec2 texCoord;out vec4 x3d_FragColor;uniform sampler2D x3d_PanoramaTextureEXT;uniform int x3d_CurrentFaceEXT;vec3 uvToXYZ(const in int face,const in vec2 uv){switch(face){case 0:return vec3(1.,uv.y,uv.x);case 1:return vec3(-1.,uv.y,-uv.x);case 2:return vec3(uv.x,uv.y,-1.);case 3:return vec3(-uv.x,uv.y,1.);case 4:return vec3(uv.y,-1.,uv.x);default:return vec3(-uv.y,1.,uv.x);}}vec2 dirToUV(const in vec3 dir){return vec2(.5+.5*atan(dir.z,dir.x)/M_PI,1.-acos(dir.y)/M_PI);}vec3 panoramaToCubeMap(const in int face,const in vec2 texCoord){vec3 scan=uvToXYZ(face,texCoord);vec3 direction=normalize(scan);vec2 src=dirToUV(direction);return texture(x3d_PanoramaTextureEXT,src).rgb;}void main(){x3d_FragColor=vec4(panoramaToCubeMap(x3d_CurrentFaceEXT,texCoord),1.);}`
;

/* harmony default export */ const Panorama2_fs = (external_X_ITE_X3D_Namespace_default().add ("Panorama2.fs", __default__));
;// ./src/x_ite/Browser/CubeMapTexturing/X3DCubeMapTexturingContext.js


const _panoramaShader = Symbol ();

function X3DCubeMapTexturingContext () { }

Object .assign (X3DCubeMapTexturingContext .prototype,
{
   getPanoramaShader ()
   {
      return this [_panoramaShader] ??= this .createShader ({
         name: "Panorama",
         vertexShader: "FullScreen",
         fragmentShader: `data:x-shader/x-fragment,${Panorama2_fs}`,
         uniforms: ["x3d_PanoramaTextureEXT", "x3d_CurrentFaceEXT"],
      });
   },
});

const X3DCubeMapTexturingContext_default_ = X3DCubeMapTexturingContext;
;

/* harmony default export */ const CubeMapTexturing_X3DCubeMapTexturingContext = (external_X_ITE_X3D_Namespace_default().add ("X3DCubeMapTexturingContext", X3DCubeMapTexturingContext_default_));
;// external "__X_ITE_X3D__ .Fields"
const external_X_ITE_X3D_Fields_namespaceObject = __X_ITE_X3D__ .Fields;
var external_X_ITE_X3D_Fields_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Fields_namespaceObject);
;// external "__X_ITE_X3D__ .X3DFieldDefinition"
const external_X_ITE_X3D_X3DFieldDefinition_namespaceObject = __X_ITE_X3D__ .X3DFieldDefinition;
var external_X_ITE_X3D_X3DFieldDefinition_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DFieldDefinition_namespaceObject);
;// external "__X_ITE_X3D__ .FieldDefinitionArray"
const external_X_ITE_X3D_FieldDefinitionArray_namespaceObject = __X_ITE_X3D__ .FieldDefinitionArray;
var external_X_ITE_X3D_FieldDefinitionArray_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_FieldDefinitionArray_namespaceObject);
;// external "__X_ITE_X3D__ .X3DNode"
const external_X_ITE_X3D_X3DNode_namespaceObject = __X_ITE_X3D__ .X3DNode;
var external_X_ITE_X3D_X3DNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DNode_namespaceObject);
;// external "__X_ITE_X3D__ .X3DSingleTextureNode"
const external_X_ITE_X3D_X3DSingleTextureNode_namespaceObject = __X_ITE_X3D__ .X3DSingleTextureNode;
var external_X_ITE_X3D_X3DSingleTextureNode_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DSingleTextureNode_namespaceObject);
;// external "__X_ITE_X3D__ .X3DConstants"
const external_X_ITE_X3D_X3DConstants_namespaceObject = __X_ITE_X3D__ .X3DConstants;
var external_X_ITE_X3D_X3DConstants_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DConstants_namespaceObject);
;// ./src/x_ite/Components/CubeMapTexturing/X3DEnvironmentTextureNode.js




function X3DEnvironmentTextureNode (executionContext)
{
   external_X_ITE_X3D_X3DSingleTextureNode_default().call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).X3DEnvironmentTextureNode);

   // Private properties

   const gl = this .getBrowser () .getContext ();

   this .target = gl .TEXTURE_CUBE_MAP;

   this .targets = [
      gl .TEXTURE_CUBE_MAP_POSITIVE_Z, // Front
      gl .TEXTURE_CUBE_MAP_NEGATIVE_Z, // Back
      gl .TEXTURE_CUBE_MAP_NEGATIVE_X, // Left
      gl .TEXTURE_CUBE_MAP_POSITIVE_X, // Right
      gl .TEXTURE_CUBE_MAP_POSITIVE_Y, // Top
      gl .TEXTURE_CUBE_MAP_NEGATIVE_Y, // Bottom
   ];
}

Object .assign (Object .setPrototypeOf (X3DEnvironmentTextureNode .prototype, (external_X_ITE_X3D_X3DSingleTextureNode_default()).prototype),
{
   initialize ()
   {
      external_X_ITE_X3D_X3DSingleTextureNode_default().prototype .initialize .call (this);

      this .clearTexture ();
   },
   getTarget ()
   {
      return this .target;
   },
   getTargets ()
   {
      return this .targets;
   },
   getTextureType ()
   {
      return 4;
   },
   getSize ()
   {
      return this .size;
   },
   setSize (value)
   {
      this .size = value;

      // https://stackoverflow.com/a/25640078/1818915
      // The system will automatically clamp the specified parameter appropriately.
      // In GLSL 4 there is a textureQueryLevels function,
      // otherwise: levels = 1 + floor (log2 (size)).
      // We subtract one (1) here, because glsl texture lod starts with 0.
      this .levels = Math .floor (Math .log2 (Math .max (value, 1)));
   },
   getLevels ()
   {
      return this .levels;
   },
   clearTexture: (() =>
   {
      const defaultData = new Uint8Array ([ 255, 255, 255, 255 ]);

      return function ()
      {
         const gl = this .getBrowser () .getContext ();

         gl .bindTexture (this .getTarget (), this .getTexture ());

         for (const target of this .getTargets ())
            gl .texImage2D (target, 0, gl .RGBA, 1, 1, 0, gl .RGBA, gl .UNSIGNED_BYTE, defaultData);

         this .setSize (1);
         this .setTransparent (false);
         this .updateTextureParameters ();
         this .addNodeEvent ();
      };
   })(),
   updateTextureParameters ()
   {
      external_X_ITE_X3D_X3DSingleTextureNode_default().prototype .updateTextureParameters .call (this,
                                                                      this .target,
                                                                      this ._textureProperties .getValue (),
                                                                      this .texturePropertiesNode,
                                                                      this .size,
                                                                      this .size,
                                                                      false,
                                                                      false,
                                                                      false);
   },
   setShaderUniforms (gl, channel)
   {
      const textureUnit = this .getBrowser () .popTextureUnit ();

      gl .activeTexture (gl .TEXTURE0 + textureUnit);
      gl .bindTexture (gl .TEXTURE_CUBE_MAP, this .getTexture ());
      gl .uniform1i (channel .textureCube, textureUnit);
   },
});

Object .defineProperties (X3DEnvironmentTextureNode, external_X_ITE_X3D_X3DNode_default().getStaticProperties ("X3DEnvironmentTextureNode", "CubeMapTexturing", 1));

const X3DEnvironmentTextureNode_default_ = X3DEnvironmentTextureNode;
;

/* harmony default export */ const CubeMapTexturing_X3DEnvironmentTextureNode = (external_X_ITE_X3D_Namespace_default().add ("X3DEnvironmentTextureNode", X3DEnvironmentTextureNode_default_));
;// external "__X_ITE_X3D__ .X3DCast"
const external_X_ITE_X3D_X3DCast_namespaceObject = __X_ITE_X3D__ .X3DCast;
var external_X_ITE_X3D_X3DCast_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DCast_namespaceObject);
;// external "__X_ITE_X3D__ .BitSet"
const external_X_ITE_X3D_BitSet_namespaceObject = __X_ITE_X3D__ .BitSet;
var external_X_ITE_X3D_BitSet_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_BitSet_namespaceObject);
;// ./src/x_ite/Components/CubeMapTexturing/ComposedCubeMapTexture.js









function ComposedCubeMapTexture (executionContext)
{
   CubeMapTexturing_X3DEnvironmentTextureNode .call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).ComposedCubeMapTexture);

   this .addChildObjects ((external_X_ITE_X3D_X3DConstants_default()).outputOnly, "update", new (external_X_ITE_X3D_Fields_default()).SFTime ());

   // Legacy

   if (executionContext .getSpecificationVersion () <= 3.3)
   {
      this .addAlias ("front",  this ._frontTexture);
      this .addAlias ("back",   this ._backTexture);
      this .addAlias ("left",   this ._leftTexture);
      this .addAlias ("right",  this ._rightTexture);
      this .addAlias ("top",    this ._topTexture);
      this .addAlias ("bottom", this ._bottomTexture);
   }

   // Private properties

   this .textureNodes = [null, null, null, null, null, null];
   this .textureBits  = new (external_X_ITE_X3D_BitSet_default()) ();
}

Object .assign (Object .setPrototypeOf (ComposedCubeMapTexture .prototype, CubeMapTexturing_X3DEnvironmentTextureNode .prototype),
{
   initialize ()
   {
      CubeMapTexturing_X3DEnvironmentTextureNode .prototype .initialize .call (this);

      const gl = this .getBrowser () .getContext ();

      this .frameBuffer = gl .createFramebuffer ();

      // Initialize.

      this ._frontTexture  .addInterest ("set_texture__", this, 0);
      this ._backTexture   .addInterest ("set_texture__", this, 1);
      this ._leftTexture   .addInterest ("set_texture__", this, 2);
      this ._rightTexture  .addInterest ("set_texture__", this, 3);
      this ._topTexture    .addInterest ("set_texture__", this, 5);
      this ._bottomTexture .addInterest ("set_texture__", this, 4);
      this ._update        .addInterest ("update",        this);

      this .set_texture__ (0, this ._frontTexture);
      this .set_texture__ (1, this ._backTexture);
      this .set_texture__ (2, this ._leftTexture);
      this .set_texture__ (3, this ._rightTexture);
      this .set_texture__ (4, this ._topTexture);
      this .set_texture__ (5, this ._bottomTexture);
   },
   set_texture__ (index, node)
   {
      let textureNode = this .textureNodes [index];

      textureNode ?.removeInterest ("set_loadState__", this);

      textureNode = this .textureNodes [index] = external_X_ITE_X3D_X3DCast_default() ((external_X_ITE_X3D_X3DConstants_default()).X3DTexture2DNode, node);

      textureNode ?.addInterest ("set_loadState__", this, index, textureNode);

      this .set_loadState__ (index, textureNode);
   },
   set_loadState__ (index, textureNode)
   {
      this .setTextureBit (index, textureNode ?.checkLoadState ());

      this ._update .addEvent ();
   },
   setTextureBit (bit, loadState)
   {
      this .textureBits .set (bit, loadState === (external_X_ITE_X3D_X3DConstants_default()).COMPLETE_STATE);
   },
   isComplete ()
   {
      if (+this .textureBits !== 0b111111)
         return false;

      const
         textureNodes = this .textureNodes,
         size         = textureNodes [0] .getWidth ();

      for (const textureNode of textureNodes)
      {
         if (textureNode .getWidth () !== size)
            return false;

         if (textureNode .getHeight () !== size)
            return false;
      }

      return true;
   },
   update ()
   {
      if (this .isComplete ())
      {
         const
            gl           = this .getBrowser () .getContext (),
            textureNodes = this .textureNodes,
            size         = textureNodes [0] .getWidth ();

         // Prepare faces. This is necessary for Chrome and Firefox.

         if (size !== this .getSize ())
         {
            const defaultData = new Uint8Array (size * size * 4);

            gl .bindTexture (this .getTarget (), this .getTexture ());

            for (let i = 0; i < 6; ++ i)
               gl .texImage2D (this .getTargets () [i], 0, gl .RGBA, size, size, 0, gl .RGBA, gl .UNSIGNED_BYTE, defaultData);

            this .setSize (size);
            this .updateTextureParameters ();
         }

         // Fill with texture data.

         gl .bindFramebuffer (gl .FRAMEBUFFER, this .frameBuffer);

         for (let i = 0; i < 6; ++ i)
         {
            const textureNode = textureNodes [i];

            // Copy color texture.

            gl .bindTexture (gl .TEXTURE_2D, textureNode .getTexture ());
            gl .framebufferTexture2D (gl .FRAMEBUFFER, gl .COLOR_ATTACHMENT0, gl .TEXTURE_2D, textureNode .getTexture (), 0);
            gl .bindTexture (this .getTarget (), this .getTexture ());

            if (textureNode .getTextureType () === 1)
            {
               gl .copyTexSubImage2D (this .getTargets () [i], 0, 0, 0, 0, 0, size, size);
            }
            else
            {
               // Copy and flip Y.
               for (let y = 0; y < size; ++ y)
                  gl .copyTexSubImage2D (this .getTargets () [i], 0, 0, size - y - 1, 0, y, size, 1);
            }
         }

         this .setTransparent (textureNodes .some (textureNode => textureNode .isTransparent ()));
         this .setLinear (textureNodes .some (textureNode => textureNode .isLinear ()));
         this .setMipMaps (textureNodes .every (textureNode => textureNode .canMipMaps ()));
         this .updateTextureParameters ();
         this .addNodeEvent ();
      }
      else
      {
         this .clearTexture ();
      }
   },
   getRenderedTextures (renderedTextures)
   {
      for (const textureNode of this .textureNodes)
         textureNode ?.getRenderedTextures (renderedTextures);
   },
});

Object .defineProperties (ComposedCubeMapTexture,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("ComposedCubeMapTexture", "CubeMapTexturing", 1, "texture", "3.1"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "metadata",          new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "description",       new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "frontTexture",      new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "backTexture",       new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "leftTexture",       new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "rightTexture",      new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "topTexture",        new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "bottomTexture",     new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "textureProperties", new (external_X_ITE_X3D_Fields_default()).SFNode ()),
      ]),
      enumerable: true,
   },
});

const ComposedCubeMapTexture_default_ = ComposedCubeMapTexture;
;

/* harmony default export */ const CubeMapTexturing_ComposedCubeMapTexture = (external_X_ITE_X3D_Namespace_default().add ("ComposedCubeMapTexture", ComposedCubeMapTexture_default_));
;// external "__X_ITE_X3D__ .DependentRenderer"
const external_X_ITE_X3D_DependentRenderer_namespaceObject = __X_ITE_X3D__ .DependentRenderer;
var external_X_ITE_X3D_DependentRenderer_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_DependentRenderer_namespaceObject);
;// external "__X_ITE_X3D__ .TextureBuffer"
const external_X_ITE_X3D_TextureBuffer_namespaceObject = __X_ITE_X3D__ .TextureBuffer;
var external_X_ITE_X3D_TextureBuffer_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_TextureBuffer_namespaceObject);
;// external "__X_ITE_X3D__ .TraverseType"
const external_X_ITE_X3D_TraverseType_namespaceObject = __X_ITE_X3D__ .TraverseType;
var external_X_ITE_X3D_TraverseType_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_TraverseType_namespaceObject);
;// external "__X_ITE_X3D__ .Camera"
const external_X_ITE_X3D_Camera_namespaceObject = __X_ITE_X3D__ .Camera;
var external_X_ITE_X3D_Camera_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Camera_namespaceObject);
;// external "__X_ITE_X3D__ .ViewVolume"
const external_X_ITE_X3D_ViewVolume_namespaceObject = __X_ITE_X3D__ .ViewVolume;
var external_X_ITE_X3D_ViewVolume_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_ViewVolume_namespaceObject);
;// external "__X_ITE_X3D__ .Rotation4"
const external_X_ITE_X3D_Rotation4_namespaceObject = __X_ITE_X3D__ .Rotation4;
var external_X_ITE_X3D_Rotation4_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Rotation4_namespaceObject);
;// external "__X_ITE_X3D__ .Vector3"
const external_X_ITE_X3D_Vector3_namespaceObject = __X_ITE_X3D__ .Vector3;
var external_X_ITE_X3D_Vector3_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Vector3_namespaceObject);
;// external "__X_ITE_X3D__ .Vector4"
const external_X_ITE_X3D_Vector4_namespaceObject = __X_ITE_X3D__ .Vector4;
var external_X_ITE_X3D_Vector4_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Vector4_namespaceObject);
;// external "__X_ITE_X3D__ .Matrix4"
const external_X_ITE_X3D_Matrix4_namespaceObject = __X_ITE_X3D__ .Matrix4;
var external_X_ITE_X3D_Matrix4_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Matrix4_namespaceObject);
;// external "__X_ITE_X3D__ .Algorithm"
const external_X_ITE_X3D_Algorithm_namespaceObject = __X_ITE_X3D__ .Algorithm;
var external_X_ITE_X3D_Algorithm_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Algorithm_namespaceObject);
;// ./src/x_ite/Components/CubeMapTexturing/GeneratedCubeMapTexture.js

















function GeneratedCubeMapTexture (executionContext)
{
   CubeMapTexturing_X3DEnvironmentTextureNode .call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).GeneratedCubeMapTexture);

   // Private properties

   this .dependentRenderers = new WeakMap ();
   this .projectionMatrix   = new (external_X_ITE_X3D_Matrix4_default()) ();
   this .modelMatrix        = new (external_X_ITE_X3D_Matrix4_default()) ();
   this .updateCallbacks    = new Map ();
}

Object .assign (Object .setPrototypeOf (GeneratedCubeMapTexture .prototype, CubeMapTexturing_X3DEnvironmentTextureNode .prototype),
{
   initialize ()
   {
      CubeMapTexturing_X3DEnvironmentTextureNode .prototype .initialize .call (this);

      // Initialize.

      this ._size .addInterest ("set_size__", this);

      this .set_size__ ();
   },
   isRenderedTexture ()
   {
      return true;
   },
   getRenderedTextures (renderedTextures)
   {
      renderedTextures .add (this);
   },
   addUpdateCallback (key, callback)
   {
      this .updateCallbacks .set (key, callback);
   },
   removeUpdateCallback (key)
   {
      this .updateCallbacks .delete (key);
   },
   set_size__ ()
   {
      const size = this ._size .getValue ();

      // Dispose old framebuffer.

      this .frameBuffer ?.dispose ();

      // Transfer 6 textures of size x size pixels.

      if (size > 0)
      {
         // Upload default data.

         const
            browser     = this .getBrowser (),
            gl          = browser .getContext (),
            defaultData = new Uint8Array (size * size * 4);

         gl .bindTexture (this .getTarget (), this .getTexture ());

         for (const target of this .getTargets ())
            gl .texImage2D (target, 0, gl .RGBA, size, size, 0, gl .RGBA, gl .UNSIGNED_BYTE, defaultData);

         this .updateTextureParameters ();

         // Properties

         this .viewport    = new (external_X_ITE_X3D_Vector4_default()) (0, 0, size, size);
         this .frameBuffer = new (external_X_ITE_X3D_TextureBuffer_default()) ({ browser, width: size, height: size });

         this .setSize (size);
      }
      else
      {
         this .frameBuffer = null;

         this .clearTexture ();
      }
   },
   traverse (type, renderObject)
   {
      // TraverseType .DISPLAY

      if (!renderObject .isIndependent ())
         return;

      if (!this .frameBuffer)
         return;

      if (this ._update .getValue () === "NONE")
         return;

      renderObject .getRenderedTextures () .add (this);

      this .modelMatrix .assign (renderObject .getModelViewMatrix () .get ())
         .multRight (renderObject .getCameraSpaceMatrix () .get ());
   },
   renderTexture: (() =>
   {
      // Rotations to negated normals of the texture cube.

      const rotations = [
         external_X_ITE_X3D_Rotation4_default().fromVectors ((external_X_ITE_X3D_Vector3_default()).Z_AXIS, (external_X_ITE_X3D_Vector3_default()).NEGATIVE_Z_AXIS), // front
         external_X_ITE_X3D_Rotation4_default().fromVectors ((external_X_ITE_X3D_Vector3_default()).Z_AXIS, (external_X_ITE_X3D_Vector3_default()).Z_AXIS),          // back
         external_X_ITE_X3D_Rotation4_default().fromVectors ((external_X_ITE_X3D_Vector3_default()).Z_AXIS, (external_X_ITE_X3D_Vector3_default()).X_AXIS),          // left
         external_X_ITE_X3D_Rotation4_default().fromVectors ((external_X_ITE_X3D_Vector3_default()).Z_AXIS, (external_X_ITE_X3D_Vector3_default()).NEGATIVE_X_AXIS), // right
         external_X_ITE_X3D_Rotation4_default().fromVectors ((external_X_ITE_X3D_Vector3_default()).Z_AXIS, (external_X_ITE_X3D_Vector3_default()).NEGATIVE_Y_AXIS), // top
         external_X_ITE_X3D_Rotation4_default().fromVectors ((external_X_ITE_X3D_Vector3_default()).Z_AXIS, (external_X_ITE_X3D_Vector3_default()).Y_AXIS),          // bottom
      ];

      // Negated scales of the texture cube.

      const scales = [
         new (external_X_ITE_X3D_Vector3_default()) (-1, -1,  1), // front
         new (external_X_ITE_X3D_Vector3_default()) (-1, -1,  1), // back
         new (external_X_ITE_X3D_Vector3_default()) (-1, -1,  1), // left
         new (external_X_ITE_X3D_Vector3_default()) (-1, -1,  1), // right
         new (external_X_ITE_X3D_Vector3_default()) ( 1,  1,  1), // top
         new (external_X_ITE_X3D_Vector3_default()) ( 1,  1,  1), // bottom
      ];

      const
         invCameraSpaceMatrix = new (external_X_ITE_X3D_Matrix4_default()) (),
         viewVolume           = new (external_X_ITE_X3D_ViewVolume_default()) ();

      return function (renderObject)
      {
         this .textureRenderingPass = true;

         // Make dependent renderer.

         if (!this .dependentRenderers .has (renderObject))
            this .dependentRenderers .set (renderObject, new (external_X_ITE_X3D_DependentRenderer_default()) (this .getExecutionContext (), renderObject));

         // Prepare.

         const
            dependentRenderer  = this .dependentRenderers .get (renderObject),
            browser            = this .getBrowser (),
            gl                 = browser .getContext (),
            viewport           = this .viewport,
            background         = dependentRenderer .getBackground (),
            navigationInfoNode = dependentRenderer .getNavigationInfo (),
            viewpointNode      = dependentRenderer .getViewpoint (),
            headlightContainer = browser .getHeadlight (),
            headlight          = navigationInfoNode ._headlight .getValue (),
            nearValue          = viewpointNode .getNearDistance (navigationInfoNode),
            farValue           = viewpointNode .getFarDistance (navigationInfoNode),
            projectionMatrix   = external_X_ITE_X3D_Camera_default().perspective (external_X_ITE_X3D_Algorithm_default().radians (90), nearValue, farValue, 1, 1, this .projectionMatrix),
            width              = this .frameBuffer .getWidth (),
            height             = this .frameBuffer .getHeight ();

         this .setTransparent (background .isTransparent ());

         dependentRenderer .setFramebuffer (this .frameBuffer);
         dependentRenderer .getViewVolumes () .push (viewVolume .set (projectionMatrix, viewport));
         dependentRenderer .getProjectionMatrix () .push (projectionMatrix);

         gl .bindTexture (this .getTarget (), this .getTexture ());

         this .frameBuffer .bind ();

         for (let i = 0; i < 6; ++ i)
         {
            gl .viewport (... viewport);
            gl .scissor (... viewport);
            gl .clearColor (0, 0, 0, 0);
            gl .clear (gl .COLOR_BUFFER_BIT); // Always clear, X3DBackground could be transparent!

            // Setup inverse texture space matrix.

            dependentRenderer .getCameraSpaceMatrix () .push (this .modelMatrix);
            dependentRenderer .getCameraSpaceMatrix () .rotate (rotations [i]);
            dependentRenderer .getCameraSpaceMatrix () .scale (scales [i]);

            invCameraSpaceMatrix .assign (dependentRenderer .getCameraSpaceMatrix () .get ()) .inverse ();

            dependentRenderer .getViewMatrix ()      .push (invCameraSpaceMatrix);
            dependentRenderer .getModelViewMatrix () .push (invCameraSpaceMatrix);

            // Setup headlight if enabled.

            if (headlight)
            {
               headlightContainer .modelViewMatrix .push (invCameraSpaceMatrix);
               headlightContainer .modelViewMatrix .multLeft (viewpointNode .getCameraSpaceMatrix ());
            }

            // Render layer's children.

            renderObject .getLayer () .traverse ((external_X_ITE_X3D_TraverseType_default()).DISPLAY, dependentRenderer);

            // Pop matrices.

            if (headlight)
               headlightContainer .modelViewMatrix .pop ();

            dependentRenderer .getModelViewMatrix ()   .pop ();
            dependentRenderer .getCameraSpaceMatrix () .pop ();
            dependentRenderer .getViewMatrix ()        .pop ();

            // Transfer image.

            gl .bindTexture (this .getTarget (), this .getTexture ());
            gl .copyTexSubImage2D (this .getTargets () [i], 0, 0, 0, 0, 0, width, height);
         }

         this .updateTextureParameters ();

         dependentRenderer .getProjectionMatrix () .pop ();
         dependentRenderer .getViewVolumes      () .pop ();

         if (this ._update .equals ("NEXT_FRAME_ONLY"))
            this ._update = "NONE";

         for (const callback of this .updateCallbacks .values ())
            callback ();

         this .textureRenderingPass = false;
      };
   })(),
   setShaderUniforms (gl, channel)
   {
      CubeMapTexturing_X3DEnvironmentTextureNode .prototype .setShaderUniforms .call (this, gl, channel);

      if (!this .textureRenderingPass)
         return;

      // Hide object by making scissor zero size.
      gl .scissor (0, 0, 0, 0);
   },
});

Object .defineProperties (GeneratedCubeMapTexture,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("GeneratedCubeMapTexture", "CubeMapTexturing", 3, "texture", "3.0"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "metadata",          new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "description",       new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "update",            new (external_X_ITE_X3D_Fields_default()).SFString ("NONE")),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "size",              new (external_X_ITE_X3D_Fields_default()).SFInt32 (128)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "textureProperties", new (external_X_ITE_X3D_Fields_default()).SFNode ()),
      ]),
      enumerable: true,
   },
});

const GeneratedCubeMapTexture_default_ = GeneratedCubeMapTexture;
;

/* harmony default export */ const CubeMapTexturing_GeneratedCubeMapTexture = (external_X_ITE_X3D_Namespace_default().add ("GeneratedCubeMapTexture", GeneratedCubeMapTexture_default_));
;// external "__X_ITE_X3D__ .X3DUrlObject"
const external_X_ITE_X3D_X3DUrlObject_namespaceObject = __X_ITE_X3D__ .X3DUrlObject;
var external_X_ITE_X3D_X3DUrlObject_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_X3DUrlObject_namespaceObject);
;// external "__X_ITE_X3D__ .FileLoader"
const external_X_ITE_X3D_FileLoader_namespaceObject = __X_ITE_X3D__ .FileLoader;
var external_X_ITE_X3D_FileLoader_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_FileLoader_namespaceObject);
;// external "__X_ITE_X3D__ .Vector2"
const external_X_ITE_X3D_Vector2_namespaceObject = __X_ITE_X3D__ .Vector2;
var external_X_ITE_X3D_Vector2_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_Vector2_namespaceObject);
;// external "__X_ITE_X3D__ .DEVELOPMENT"
const external_X_ITE_X3D_DEVELOPMENT_namespaceObject = __X_ITE_X3D__ .DEVELOPMENT;
var external_X_ITE_X3D_DEVELOPMENT_default = /*#__PURE__*/__webpack_require__.n(external_X_ITE_X3D_DEVELOPMENT_namespaceObject);
;// ./src/x_ite/Components/CubeMapTexturing/ImageCubeMapTexture.js











function ImageCubeMapTexture (executionContext)
{
   CubeMapTexturing_X3DEnvironmentTextureNode .call (this, executionContext);
   external_X_ITE_X3D_X3DUrlObject_default().call (this, executionContext);

   this .addType ((external_X_ITE_X3D_X3DConstants_default()).ImageCubeMapTexture);
}

Object .assign (Object .setPrototypeOf (ImageCubeMapTexture .prototype, CubeMapTexturing_X3DEnvironmentTextureNode .prototype),
   (external_X_ITE_X3D_X3DUrlObject_default()).prototype,
{
   initialize ()
   {
      CubeMapTexturing_X3DEnvironmentTextureNode .prototype .initialize .call (this);
      external_X_ITE_X3D_X3DUrlObject_default().prototype .initialize .call (this);

      this .requestImmediateLoad () .catch (Function .prototype);
   },
   unloadData ()
   {
      this .clearTexture ();
   },
   loadData ()
   {
      new (external_X_ITE_X3D_FileLoader_default()) (this, { dataAsString: false }) .loadDocument (this ._url, async (data, fileURL) =>
      {
         if (data === null)
         {
            this .clearTexture ();
            this .setLoadState ((external_X_ITE_X3D_X3DConstants_default()).FAILED_STATE);
         }
         else if (data instanceof ArrayBuffer)
         {
            fileURL = new URL (fileURL);

            if (fileURL .pathname .match (/\.ktx2?(?:\.gz)?$/) || fileURL .href .match (/^\s*data:image\/ktx2[;,]/s))
            {
               this .setLinear (true);
               this .setMipMaps (false);

               const
                  decoder = await this .getBrowser () .getKTXDecoder (),
                  texture = await decoder .loadKTXFromBuffer (data);

               this .setKTXTexture (texture, fileURL);
            }
            else
            {
               this .setLinear (false);
               this .setMipMaps (true);

               const objectURL = URL .createObjectURL (new Blob ([data]));

               try
               {
                  this .setImage (await this .loadImage (objectURL), fileURL);
               }
               finally
               {
                  URL .revokeObjectURL (objectURL);
               }
            }
         }
         else
         {
            throw new Error (`${this .getTypeName ()}: No suitable file handler found.`);
         }
      });
   },
   setKTXTexture (texture, fileURL)
   {
      if (texture .target !== this .getTarget ())
         throw new Error ("Invalid KTX texture target, must be 'TEXTURE_CUBE_MAP'.");

      if ((external_X_ITE_X3D_DEVELOPMENT_default()))
      {
         if (fileURL .protocol !== "data:")
            console .info (`Done loading ${this .getTypeName ()} '${decodeURI (fileURL)}'.`);
      }

      this .setTexture (texture);
      this .setTransparent (false);
      this .setSize (texture .baseWidth);
      this .updateTextureParameters ();

      this .setLoadState ((external_X_ITE_X3D_X3DConstants_default()).COMPLETE_STATE);
   },
   setImage (image, fileURL)
   {
      if ((external_X_ITE_X3D_DEVELOPMENT_default()))
      {
         if (fileURL .protocol !== "data:")
            console .info (`Done loading ${this .getTypeName ()} '${decodeURI (fileURL)}'.`);
      }

      // Create texture.

      const
         gl      = this .getBrowser () .getContext (),
         texture = gl .createTexture ();

      gl .bindTexture (gl .TEXTURE_2D, texture);
      gl .texImage2D (gl .TEXTURE_2D, 0, gl .RGBA, gl .RGBA, gl .UNSIGNED_BYTE, image);
      gl .texParameteri (gl .TEXTURE_2D, gl .TEXTURE_MIN_FILTER, gl .LINEAR);
      gl .texParameteri (gl .TEXTURE_2D, gl .TEXTURE_MAG_FILTER, gl .LINEAR);
      gl .texParameteri (gl .TEXTURE_2D, gl .TEXTURE_WRAP_S, gl .CLAMP_TO_EDGE);
      gl .texParameteri (gl .TEXTURE_2D, gl .TEXTURE_WRAP_T, gl .CLAMP_TO_EDGE);

      this .imageToCubeMap (texture, image .width, image .height, false);

      // Update load state.

      this .setLoadState ((external_X_ITE_X3D_X3DConstants_default()).COMPLETE_STATE);
      this .addNodeEvent ();
   },
   imageToCubeMap (texture, width, height)
   {
      const aspectRatio = width / height;

      if (Math .abs (aspectRatio - 4/3) < 0.01)
         this .skyBoxToCubeMap (texture, width, height);

      if (Math .abs (aspectRatio - 2/1) < 0.01)
         this .panoramaToCubeMap (texture, width, height);

      this .updateTextureParameters ();
   },
   skyBoxToCubeMap: (() =>
   {
      const offsets = [
         new (external_X_ITE_X3D_Vector2_default()) (1, 1), // Front
         new (external_X_ITE_X3D_Vector2_default()) (3, 1), // Back
         new (external_X_ITE_X3D_Vector2_default()) (0, 1), // Left
         new (external_X_ITE_X3D_Vector2_default()) (2, 1), // Right
         new (external_X_ITE_X3D_Vector2_default()) (1, 0), // Top
         new (external_X_ITE_X3D_Vector2_default()) (1, 2), // Bottom
      ];

      //     -----
      //     | t |
      // -----------------
      // | l | f | r | b |
      // -----------------
      //     | b |
      //     -----

      return function (skyBoxTexture, width, height)
      {
         const
            gl          = this .getBrowser () .getContext (),
            framebuffer = gl .createFramebuffer (),
            width1_4    = Math .floor (width / 4),
            height1_3   = Math .floor (height / 3),
            data        = new Uint8Array (width1_4 * height1_3 * 4);

         // Init cube map texture.

         gl .bindTexture (this .getTarget (), this .getTexture ());

         for (let i = 0; i < 6; ++ i)
            gl .texImage2D  (this .getTargets () [i], 0, gl .RGBA, width1_4, height1_3, 0, gl .RGBA, gl .UNSIGNED_BYTE, null);

         // Extract images.

         gl .bindFramebuffer (gl .FRAMEBUFFER, framebuffer);
         gl .framebufferTexture2D (gl .FRAMEBUFFER, gl .COLOR_ATTACHMENT0, gl .TEXTURE_2D, skyBoxTexture, 0);

         let transparent = false;

         gl .bindTexture (this .getTarget (), this .getTexture ());

         for (let i = 0; i < 6; ++ i)
         {
            gl .copyTexSubImage2D (this .getTargets () [i], 0, 0, 0, offsets [i] .x * width1_4, offsets [i] .y * height1_3, width1_4, height1_3);

            // Determine image alpha.

            if (!transparent)
            {
               gl .readPixels (offsets [i] .x * width1_4, offsets [i] .y * height1_3, width1_4, height1_3, gl .RGBA, gl .UNSIGNED_BYTE, data);

               transparent = this .isImageTransparent (data);
            }
         }

         gl .deleteFramebuffer (framebuffer);
         gl .deleteTexture (skyBoxTexture);

         // Update size and transparent field.

         this .setTransparent (transparent);
         this .setSize (width1_4);
      };
   })(),
   panoramaToCubeMap (panoramaTexture, width, height)
   {
      // Mercator Projection

      const
         browser     = this .getBrowser (),
         gl          = browser .getContext (),
         shaderNode  = browser .getPanoramaShader (),
         framebuffer = gl .createFramebuffer (),
         size        = Math .floor (height / 2),
         data        = new Uint8Array (size * size * 4);

      // Adjust panorama texture.

      gl .bindTexture (gl .TEXTURE_2D, panoramaTexture);
      gl .texParameteri (gl .TEXTURE_2D, gl .TEXTURE_WRAP_S, gl .MIRRORED_REPEAT);
      gl .texParameteri (gl .TEXTURE_2D, gl .TEXTURE_WRAP_T, gl .MIRRORED_REPEAT);
      gl .texParameteri (gl .TEXTURE_2D, gl .TEXTURE_MIN_FILTER, gl .LINEAR);
      gl .texParameteri (gl .TEXTURE_2D, gl .TEXTURE_MAG_FILTER, gl .LINEAR);

      // Init cube map texture.

      gl .bindTexture (this .getTarget (), this .getTexture ());

      for (let i = 0; i < 6; ++ i)
         gl .texImage2D  (this .getTargets () [i], 0, gl .RGBA, size, size, 0, gl .RGBA, gl .UNSIGNED_BYTE, null);

      // Render faces.

      gl .useProgram (shaderNode .getProgram ());

      gl .activeTexture (gl .TEXTURE0);
      gl .bindTexture (gl .TEXTURE_2D, panoramaTexture);
      gl .uniform1i (shaderNode .x3d_PanoramaTextureEXT, 0);

      gl .bindFramebuffer (gl .FRAMEBUFFER, framebuffer);
      gl .viewport (0, 0, size, size);
      gl .scissor (0, 0, size, size);
      gl .disable (gl .DEPTH_TEST);
      gl .enable (gl .CULL_FACE);
      gl .frontFace (gl .CCW);
      gl .clearColor (0, 0, 0, 0);
      gl .bindVertexArray (browser .getFullscreenVertexArrayObject ());

      let transparent = false;

      for (let i = 0; i < 6; ++ i)
      {
         gl .framebufferTexture2D (gl .FRAMEBUFFER, gl .COLOR_ATTACHMENT0, this .getTargets () [i], this .getTexture (), 0);
         gl .clear (gl .COLOR_BUFFER_BIT);
         gl .uniform1i (shaderNode .x3d_CurrentFaceEXT, i);
         gl .drawArrays (gl .TRIANGLES, 0, 6);

         if (!transparent)
         {
            gl .readPixels (0, 0, size, size, gl .RGBA, gl .UNSIGNED_BYTE, data);

            transparent = this .isImageTransparent (data);
         }
      }

      gl .enable (gl .DEPTH_TEST);
      gl .deleteFramebuffer (framebuffer);
      gl .deleteTexture (panoramaTexture);

      // Update size and transparent field.

      this .setTransparent (transparent);
      this .setSize (size);
   },
   dispose ()
   {
      external_X_ITE_X3D_X3DUrlObject_default().prototype .dispose .call (this);
      CubeMapTexturing_X3DEnvironmentTextureNode .prototype .dispose .call (this);
   },
});

Object .defineProperties (ImageCubeMapTexture,
{
   ... external_X_ITE_X3D_X3DNode_default().getStaticProperties ("ImageCubeMapTexture", "CubeMapTexturing", 2, "texture", "3.0"),
   fieldDefinitions:
   {
      value: new (external_X_ITE_X3D_FieldDefinitionArray_default()) ([
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "metadata",             new (external_X_ITE_X3D_Fields_default()).SFNode ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "description",          new (external_X_ITE_X3D_Fields_default()).SFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "load",                 new (external_X_ITE_X3D_Fields_default()).SFBool (true)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "url",                  new (external_X_ITE_X3D_Fields_default()).MFString ()),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "autoRefresh",          new (external_X_ITE_X3D_Fields_default()).SFTime (0)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).inputOutput,    "autoRefreshTimeLimit", new (external_X_ITE_X3D_Fields_default()).SFTime (3600)),
         new (external_X_ITE_X3D_X3DFieldDefinition_default()) ((external_X_ITE_X3D_X3DConstants_default()).initializeOnly, "textureProperties",    new (external_X_ITE_X3D_Fields_default()).SFNode ()),
      ]),
      enumerable: true,
   },
});

const ImageCubeMapTexture_default_ = ImageCubeMapTexture;
;

/* harmony default export */ const CubeMapTexturing_ImageCubeMapTexture = (external_X_ITE_X3D_Namespace_default().add ("ImageCubeMapTexture", ImageCubeMapTexture_default_));
;// ./src/assets/components/CubeMapTexturingComponent.js







external_X_ITE_X3D_Components_default().add ({
   name: "CubeMapTexturing",
   concreteNodes:
   [
      CubeMapTexturing_ComposedCubeMapTexture,
      CubeMapTexturing_GeneratedCubeMapTexture,
      CubeMapTexturing_ImageCubeMapTexture,
   ],
   abstractNodes:
   [
      CubeMapTexturing_X3DEnvironmentTextureNode,
   ],
   browserContext: CubeMapTexturing_X3DCubeMapTexturingContext,
});

const CubeMapTexturingComponent_default_ = undefined;
;

/* harmony default export */ const CubeMapTexturingComponent = (external_X_ITE_X3D_Namespace_default().add ("CubeMapTexturingComponent", CubeMapTexturingComponent_default_));
/******/ })()
;